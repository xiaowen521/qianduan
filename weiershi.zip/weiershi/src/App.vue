<template>
  <div id="app">
    <!-- <img src="./assets/logo.png"> -->
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>
<script>
  	// 使用layui  里的 laydata 日期插件
//   	laydate.render({
//   		elem:'#test1',
//   		position: 'static'
//   	})
  </script>
<style>
/* #app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
} */

@media (min-width:1200px) {
	#app{
		min-width: 1200px;
		width: 1200px;;
		display: block;
		margin: 0 auto;
		position: relative;
	}
}

</style>

