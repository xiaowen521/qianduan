// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'    //引入路由

import axios from 'axios'  //引入我们的axios   作为我们的通讯 和ajax 一样
Vue.prototype.$axios = axios     //把axios 挂载到原型链上 可全局使用 axios

import Vant from 'vant'        //y引入vant 框架
import 'vant/lib/index.css'    //安装vant 框架的样式
Vue.use(Vant)                  //必须use 一下 才能使用

import Vuex from 'vuex'        //引入vuex 使用状态管理
Vue.use(Vuex)
import store from './store/store'   //引入我们的store.js

import '../src/assets/css/mystyle.css'  //引入全局的样式      ********************************* 这个是我们的手写的公共的样式
// import laydate from 'layui-laydate'   //不知道为什么 这样引用  没作用 所以屏蔽了
// import laydate from  '../static/laydate/laydate.js'   //不知道为什么 这样引用  没作用 所以屏蔽了
import '../static/laydate/theme/default/laydate.css'    //引用我们的静态的laydate.css

import swiper from 'vue-awesome-swiper'
Vue.use(swiper)
import 'swiper/dist/css/swiper.css'


import VCharts from 'v-charts'   //引入图形切换  chats  折线图 梯形图等
Vue.use(VCharts)                 //使用一下

import Mock from './mock'

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<App/>'
})
