<template>
	<div class="header">
		<div class="home_header">
			<van-nav-bar class='home_nav' title='首页' fixed @click-left='back' @click-right='home'>
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<van-icon class='right_icon' name='wap-home' slot='right' ></van-icon>
			</van-nav-bar>
		</div>
	</div>
</template>

<script>
	export default {
		name:'Pheader',
		data() {
			return {
				
			}
		},
		computed:{
			
		},
		methods:{
			back(){
				this.$router.go(-1)
			},
			home(){
				this.$router.push('/')
			}
		}
	}
</script>

<style lang="less" scoped="scoped">
	.home_nav{
		box-shadow: 0px 0px 15px #f0f0f0;
	}
	.home_nav .home-left-nav{
		color: #000000;
		vertical-align: middle;
		font-size: 14px;
		&:before{
			vertical-align: -2px;
		}
	}
	.home_nav .right_icon{
		color: #000;
		font-size: 18px;
	}
</style>
