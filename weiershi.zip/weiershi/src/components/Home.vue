<template>
	<div class="home">
		<!-- 头部引用开始 -->
		<div class="home_header">
			<van-nav-bar class='home_nav' title='首页' fixed @click-left='back()' @click-right='home()'>
				<!-- <van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon> -->
				<van-icon class='right_icon' name='wap-home' slot='right'></van-icon>
			</van-nav-bar>
		</div>
		
		<!-- 头部引用结束 -->

		<div class="content">
			<div id="test1">

			</div>
			<div class="time_line" v-for="item in timeitem">
				<van-row>
					<van-col :span='6'>
						<div class="time">
							<h4>{{item.time}}</h4>
							<template v-if="item.isok == true">
								<p>已完成</p>
							</template>
							<template v-else>
								<p>未完成</p>
							</template>

						</div>
					</van-col>
					<van-col :span='18'>
						<div class="time_icon">
							<van-icon name='circle' color='#1dae74'></van-icon>
						</div>
						<!-- 
						 -->
						<div class="time_items" @click="time_detail(item.id)">
							<template v-if="item.dot == '日程' ">
								<span class="time_sort van-ellipsis">日程</span>
							</template>
							<template v-if="item.dot == '课程' ">
								<span class="time_sort time_kecheng van-ellipsis">课程</span>
							</template>
							<template v-if="item.dot == '联系' ">
								<span class="time_sort time_lianxi van-ellipsis">联系</span>
							</template>
							<h4>{{item.title}}</h4>
							<p>课程：{{item.lesson}}</p>
							<p>地点：{{item.address}}</p>
						</div>
					</van-col>
				</van-row>
			</div>
			<!-- 下面是我们的模板 -->
			<!-- <div class="time_line">
				<van-row>
					<van-col :span='6'>
						<div class="time">
							<h4>8:00</h4>
							<p>已完成</p>
						</div>
					</van-col>
					<van-col :span='18'>
						<div class="time_icon">
							<van-icon name='circle' color='#1dae74'></van-icon>
						</div><div class="time_items">
							 <span class="time_kecheng van-ellipsis">课程</span>
							<h4>私教部周例会</h4>
							<p>课程：杨永水电费</p>
							<p>地点：拓基大厦</p>
						</div>
					</van-col>
				</van-row>
			</div> -->


			<div class="footer_height">

			</div>
		</div>

		<pfooter :activenum='1'></pfooter>

	</div>
</template>


<script>
	import laydate from '../../static/laydate/laydate.js'; //引入我们的日历js 好在我们的 mounted 中使用
	import Pheader from '@/components/Pheader'
	import Pfooter from '@/components/Pfooter'

	export default {
		name: 'home',
		components: {
			Pfooter
		},
		data() {
			return {
				msg: 'Welcome to Your Vue.js App',
				timeitem: [],

			}
		},
		methods: {
			back() {
				this.$router.go(-1)
			},
			home() {
				console.log(1)
				this.$router.push('/')
			},
			// 点击进入详情
			time_detail(id) {
				console.log(id)
				this.$router.push('/quick/schedule/scheduledetail')
			}

		},
		mounted() {
			//使用我们的laydate 来控制时间
			let that = this
			laydate.render({
				elem: '#test1',
				position: 'static',
				ready: function(data) {
					console.log(data)
					that.$axios('/api/home/times').then((res) => {
						console.log(res.data)
						that.timeitem = res.data.timeitem
					}).catch((err) => {
						that.$toast('连接出错')
					})
				},
				change: function(value) {
					console.log(value)
					that.$axios('/api/home/timess').then((res) => {
						console.log(res.data)
						that.timeitem = res.data.timeitem
					}).catch((err) => {
						that.$toast('连接出错')
					})

				}
			})

			// 初始我们获取日期的时候我们查询的当日 的进程
			// 		  this.$axios('/api/home/times').then((res)=>{
			// 			  console.log(res.data)
			// 			  this.timeitem = res.data.timeitem
			// 		  }).catch((err)=>{
			// 			  this.$toast('连接出错')
			// 		  })


		}

	}
</script>

<style>
	/* @import url(../assets/css/mystyle.css) */
	/* @import url(../../static/laydate/theme/default/laydate.css); */
	/* 引入css 我们应该同上做法 */
</style>

<style lang="less" scoped="scoped">
	// @import '../../static/laydate/theme/default/laydate.css'; //引入外部的css

	.home_nav {
		box-shadow: 0px 0px 15px #f0f0f0;
	}

	.home_nav .home-left-nav {
		color: #000000;
		vertical-align: middle;
		font-size: 14px;

		&:before {
			vertical-align: -2px;
		}
	}

	.home_nav .right_icon {
		color: #000;
		font-size: 18px;
	}

	#test1 {
		height: 313px;
		width: 100%;
		margin-bottom: 10px;
		box-shadow: 0px 0px 8px #ddd;
	}

	.time_line {
		padding: 0px 10px;
		padding-top: 20px;
		position: relative;

		.time {
			text-align: center;
			padding-top: 8px;

			p {
				font-size: 12px;
				color: #aaa;
			}
		}

		.time_icon {
			padding-top: 18px;
			display: inline-block;
			width: 15%;
			height: 100%;
			position: relative;
			vertical-align: top;
			text-align: left;
			z-index: 10;

			&:before {
				content: '';
				width: 1px;
				border-left: 1px dashed #ddd;
				position: absolute;
				height: 100px;
				max-height: 150px;
				left: 7.5px;
				top: 0px;
			}

			i {
				background: #fff;
				border-radius: 100%;
			}
		}

		.time_items {
			display: inline-block;
			width: 83%;
			padding: 10px;
			background: #fff;
			border-radius: 8px;
			box-shadow: 0px 0px 5px #ddd;
			box-sizing: border-box;

			h4 {
				font-size: 14px;
				padding-bottom: 5px;
			}

			p {
				font-size: 12px;
				color: #999;
				line-height: 20px;
			}
		}
	}

	.content {
		position: absolute;
		height: 100%;
		width: 100%;
		top: 46px;
		overflow: auto;
		background: #fafafa;
	}

	.time_sort {
		padding: 2px 5px;
		background: #74cbf1;
		float: right;
		font-size: 12px;
		border-radius: 5px;
		color: #fff;
	}

	.time_kecheng {
		padding: 2px 5px;
		background: #45c894;
		float: right;
		font-size: 12px;
		border-radius: 5px;
		color: #fff;
	}

	.time_lianxi {
		padding: 2px 5px;
		background: #ffb220;
		float: right;
		font-size: 12px;
		border-radius: 5px;
		color: #fff;
	}

	.footer_height {
		height: 80px;
	}
</style>
