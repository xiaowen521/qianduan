<template>
	<div class="personchart">
		<!-- 头部引用开始 -->
		<div class="home_header">
			<van-nav-bar class='home_nav' title='销售业绩统计' fixed  @click-left='back()' @click-right='onmore()'>
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<!-- <van-icon class='right_icon' name='ellipsis' slot='right'></van-icon> -->
			</van-nav-bar>
		</div>
		<div class="bgcolor"></div>
		<!-- 头部引用结束 -->
		<div class="person_item">
			<van-tabs v-model='personactive'>
				<van-tab title='今天'>
					
					<div class="person_header">
						<div class="header_header">
							<p>2018-11-22</p>
							<h4>1999.00<small>元</small></h4>
						</div>
						<div class="header_bottom">
							<p>共计2笔订单 , 其中1单购买，1单退费</p>
						</div>
					</div>
					<div class="person_cont">
						<div class="cont_item">11:04<span class="pull-right">购买</span></div>
						<div class="cont_name">环球金融会所一年卡</div>
						<div class="cont_money">2999.00<small>元</small></div>
						<div class="cont_look" @click="deal()">查看交易流水<van-icon name='arrow' class='icon'></van-icon></div>
					</div>
					<div class="person_cont">
						<div class="cont_item">11:04<span class="pull-right">退费</span></div>
						<div class="cont_name">环球金融会所季卡</div>
						<div class="cont_money">-1000.00<small>元</small></div>
						<div class="cont_look"  @click="deal()">查看交易流水<van-icon name='arrow' class='icon'></van-icon></div>
					</div>
					
				</van-tab>
				<van-tab title='昨天'>
					
				</van-tab>
				<van-tab title='本月'>
					
				</van-tab>
			</van-tabs>
			
		</div>
		
		
		
		
		
	</div>
</template>

<script>
	
	export default {
		name:'personchart',
		
		data(){
			return {
				personactive:0,
				
			}
		},
		methods:{
			back(){
				this.$router.go(-1)
			},
			// 打开我们的底部更多的操作
			onmore(){
				// this.$toast('more')
				this.more = true;
			},
			deal(){
				this.$router.push('/datachart/persondetail')
			}
			
		},
		mounted(){
			
		},
	}
</script>

<style lang="less" scoped="scoped">
	.person_header{
		margin-top: 10px;
		background: #fff;
		.header_header{
			border-bottom:1px solid #EFEFEF;
			p{
				line-height: 30px;
				text-align: center;
				font-size: 12px;;
			}
			h4{
				line-height: 60px;
				text-align: center;
				font-size: 26px;
				small{
					font-size: 12px;
					font-weight: normal;
					color: #898A92;
				}
			}
		}
		.header_bottom{
			padding: 10px;
			font-size: 12px;
			p{
				font-size: 12px;
			}
		}
	}
	.person_cont{
		background: #fff;
		box-sizing: border-box;
		margin: 10px;
		padding: 10px;;
		.cont_item{
			
		}
		.cont_name{
			text-align: center;
			line-height:30px;
			margin-top: 20px;
		}
		.cont_money{
			text-align: center;
			line-height: 50px;
			font-size: 20px;;
		}
		.cont_look{
			line-height: 30px;
			.icon{
				vertical-align: middle;
			}
			
		}
	}
</style>
