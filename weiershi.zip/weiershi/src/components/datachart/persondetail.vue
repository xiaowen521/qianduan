<template>
	<div class="persondetail">
		<!-- 头部引用开始 -->
		<div class="home_header">
			<van-nav-bar class='home_nav' title='交易流水' fixed  @click-left='back()' @click-right='onmore()'>
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<!-- <van-icon class='right_icon' name='ellipsis' slot='right'></van-icon> -->
			</van-nav-bar>
		</div>
		<div class="bgcolor"></div>
		<!-- 头部引用结束 -->
		
		<div class="persondetail_header">
			<div class="follow_items">
				<div class="follow_item" v-for="item in 1 " @click="entercustom(item.id)">
					<van-row>
						<van-col span='5'>
							<img src='/static/img/touxiang.png' class="photo"/>
						</van-col>
						<van-col span='14'>
							<div class="follow_center">
								<p class="follow_name">小小文</p>
								<p class="follow_ke van-ellipsis">18158873627</p>
								<!-- <p class="follow_overdue">过期时间：{{item.overdue}}</p> -->
							</div>
						</van-col>
						<van-col span='5'>
							<p class="formal">正式会员</p>
							<p class="qian">李文</p>
						</van-col>
					</van-row>
				</div>
			</div>
		</div>
			
		<div class="persondetail_cont">
			<div class="person_cont">
				<div class="cont_item">11:04<span class="pull-right">购买</span></div>
				<div class="cont_name">环球金融会所一年卡</div>
				<div class="cont_money">2999.00<small>元</small></div>
			</div>
			
		</div>
		<div class="persondetail_footer">
			
			<van-cell title='订单号' value='1020122202322'></van-cell>
			<van-cell title='购买门店' value='环球金融会所'></van-cell>
			<van-cell title='原价' value='1999.00'></van-cell>
			<van-cell title='优惠额' value='0.00'></van-cell>
			<van-cell title='操作人' value='张三'></van-cell>
			
		</div>	
			
					
				
		
		
		
		
		
	</div>
</template>

<script>
	
	export default {
		name:'personchart',
		
		data(){
			return {
				personactive:0,
				
			}
		},
		methods:{
			back(){
				this.$router.go(-1)
			},
			// 打开我们的底部更多的操作
			onmore(){
				// this.$toast('more')
				this.more = true;
			},
			deal(){
				this.$router.push('/datachart/')
			}
			
		},
		mounted(){
			
		},
	}
</script>

<style lang="less" scoped="scoped">
	.follow_items{
		margin: 10px;
		
		.checked_xuan{
			text-align: right;
			line-height: 60px;
		}
		.follow_item{
			height: 60px;
			border-bottom: 1px solid #efefef;
			padding:10px 0px;
			background:#fff;
			.photo{
				display: block;
				width: 52px;
				margin: 5px auto;
				border-radius: 100%;
			}
		}
		.follow_center{
			.follow_name{
				font-weight: bold;
				font-size: 16px;
				margin-top: 9px;
			}
			.follow_ke{
				font-size: 12px;
				color: #aaa;
			}
			.follow_overdue{
				font-size: 12px;
				color: #999;
			}
			
			p{
				line-height: 24px;
			}
		}
		.formal{
			margin-top: 3px;
		}
		.formal,.qian{
			font-size: 12px;
			color: #666;
			line-height: 28px;
			text-align: right;
			padding-right: 10px;;
		}
		
	}
	.person_cont{
		background: #fff;
		box-sizing: border-box;
		margin: 10px;
		padding: 10px;;
		.cont_item{
			
		}
		.cont_name{
			text-align: center;
			line-height:30px;
			margin-top: 20px;
		}
		.cont_money{
			text-align: center;
			line-height: 50px;
			font-size: 20px;;
		}
		.cont_look{
			line-height: 30px;
			.icon{
				vertical-align: middle;
			}
			
		}
	}
	.persondetail_footer{
		margin: 10px;
	}
</style>
