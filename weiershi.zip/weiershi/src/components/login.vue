<template>
	<div class="login">

		<div class="login_header">
			<h2>登录<span>Sign in</span></h2>
		</div>

		<div class="login_cont">
			<!-- <form></form> -->
			<div class="login_cont_shang">
				<div class="login_logo">
					<img src="../assets/img/logo.png">
				</div>

				<div class="login_form">
					<van-cell-group>
						<van-field placeholder='请输入您的工号' v-model='username' clearable class='login_input'></van-field>

						<van-field placeholder='请输入您的密码' v-model='password' clearable :right-icon='righticons' :type='typevalue' class='login_input'
						 @click-right-icon='eyes'> {{checkeyes}}</van-field>

					</van-cell-group>
					<router-link to='/forget' class='forget' >忘记密码？</router-link>
				</div>

			</div>

			<div class="login_cont_xia">
				<template v-if='loginbtn'>
					<van-button size='large' class='login_signin' disabled @click='login_in'>登录{{loginbtns}}</van-button>
				</template>
				<template v-else='loginbtn'>
					<van-button size='large' class='login_signin' @click='login_in'>登录{{loginbtns}}</van-button>
				</template>
			</div>

		</div>

	</div>
</template>

<script>
	export default {
		name: 'login',
		data() {
			return {
				loginbtn: true,
				username: '',
				password: '',
				typevalue: 'password', //转换我们的type值
				righticons: 'eye-o', // 转换我们的眼睛图标
				eyesclick: 1,
			}
		},
		computed: {
			// 检查我们的表单有没有填写  填写完整了 让按钮显示出来
			loginbtns: function() {
				if (this.username == '' || this.password == '') {
					this.loginbtn = true
				} else {
					this.loginbtn = false
				}
			},
			// 检查我们的眼睛图标有没有点击 换图标和换type属性值
			checkeyes: function() {
				if (this.eyesclick % 2 == 0) {
					this.typevalue = 'text';
					this.righticons = 'eye';
				} else {
					this.typevalue = 'password';
					this.righticons = 'eye-o';
				}
			}
		},
		methods: {

			// 点击登录出现的验证
			login_in() {
				var that = this
				this.$axios({
					url: '/api/login',
				}).then((res) => {
					console.log(res)
					if (this.username != res.data.username) {
						this.$toast('用户名不存在')
					} else if (this.password != res.data.password) {
						this.$toast('密码错误')
					} else {
						this.$toast.loading({
							loadingType: 'spinner',
							message: '正在登录'
						});
						this.$store.commit('changetoken', '123123')
						localStorage.setItem('token', '123123')
						setTimeout(function() {
							that.$router.push('/')
						}, 3000)
					}
				}).catch((err) => {
					this.$toast(err)
				})
			},
			// 点击的眼睛的判断
			eyes() {
				this.eyesclick++
			},

		}
	}
</script>

<style lang="less" scoped="scoped">
	.login {
		position: absolute;
		height: 100%;
		width: 100%;
		background: #fafafa;
	}

	.login_header {
		height: 207px;
		background-image: url(/static/img/bg_header.png);
		background-size: 100% 100%;
		position: relative;
		width: 100%;
		overflow: hidden;

		#bg_login {
			position: absolute;
			top: 0px;
			z-index: 2;
			height: 207px;
			width: 110%;
			left: -5%;
		}

		h2 {
			position: relative;
			top: 50px;
			left: 30px;
			font-size: 28px;
			font-family: PingFangSC-Medium;
			font-weight: 500;
			color: rgba(255, 255, 255, 0.88);
			line-height: 40px;
			z-index: 10;

			span {
				position: relative;
				left: 10px;
				top: -2px;
				font-size: 18px;
				font-family: PingFangSC-Medium;
				font-weight: 500;
				color: rgba(255, 255, 255, 0.52);
				line-height: 25px;
			}
		}
	}

	.login_cont {
		.login_cont_shang {
			position: relative;
			margin: 0 auto;
			margin-top: -80px;
			padding: 10px;
			box-sizing: border-box;
			z-index: 11;
			width: 327px;
			height: 350px;
			background: rgba(255, 255, 255, 1);
			box-shadow: 0px 4px 24px 0px rgba(135, 110, 40, 0.08);
			border-radius: 8px;
			
			.login_logo {
				img {
					display: block;
					margin: 46px auto;
					width: 128px;
					height: 55px;
				}
			}

			.login_form {
				.login_input {
					// border: 1px solid #ddd;
					margin-bottom: 18px;
					border-radius: 5px;
					background: #f5f5f5;

					i {
						font-size: 20px;
					}
				}

				.forget {
					color:  #898A92;;
					text-align: right;
					font-size: 12px;
					// display: block;
					float: right;
					
				}
			}

		}

		.login_cont_xia {
			width: 327px;
			margin: 50px auto 20px;

			.login_signin {
				border: 0px;
				background: linear-gradient(left, #ffc200, #ff945a);
				color: #fff;
				letter-spacing: 3px;
				padding-left: 3px;
			}
		}

	}
</style>
