<template>
	<div class="work">
		<!-- 头部引用开始 -->
		<div class="home_header">
			<van-nav-bar class='home_nav' title='工作' fixed  @click-right='tips()'>
				<!-- <van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon> -->
				<van-icon class='right_icon' name='bell' slot='right'></van-icon>
			</van-nav-bar>
		</div>
		<div class="bgcolor"></div>
		<!-- 头部引用结束 -->
		<van-tabs v-model='tabactive' sticky>
			<van-tab title='业务能力'>
				
				<div class="membership">
					<h4>会籍功能</h4>
					<div class="membership_item">
						<ul>
							<router-link to='/work/custom' tag='li'>
							<!-- <li > -->
								<div class="membership_item_cont">
									<img src="../../static/img/kehu.png">
									<p>客户管理</p>
								</div>
							<!-- </li> -->
							</router-link>
							<router-link to='/work/follow' tag='li'>
							<!-- <li> -->
								<div class="membership_item_cont">
									<img src="../../static/img/genjin.png">
									<p>跟进管理</p>
								</div>
							<!-- </li> -->
							</router-link>
							<router-link to='/work/invitation' tag='li'>
								<div class="membership_item_cont">
									<img src="../assets/img/w3.png">
									<p>邀约管理</p>
								</div>
							</router-link>
							<router-link to='/work/customsources' tag='li'>
								<div class="membership_item_cont">
									<img src="../assets/img/w4.png" class="ziyuan">
									<p>客户资源库</p>
								</div>
							</router-link>
							<li>
								<div class="membership_item_cont">
									<!-- <img src="../assets/img/a1.png">
									<p>客户管理</p> -->
								</div>
							</li>
							<li>
								<div class="membership_item_cont">
									<!-- <img src="../assets/img/a1.png">
									<p>客户管理</p> -->
								</div>
							</li>
						</ul>
					</div>
				</div>
				<div class="membership">
					<h4>教练功能</h4>
					<div class="membership_item">
						<ul>
							<router-link to='/work/tcustom' tag='li'>
								<div class="membership_item_cont">
									<img src="/static/img/jiaolian.png">
									<p>客户管理</p>
								</div>
							</router-link>
							<router-link to='/work/tfollow' tag='li'>
								<div class="membership_item_cont">
									<img src="/static/img/genjin2.png">
									<p>跟进管理</p>
								</div>
							</router-link>
							<router-link to='/work/tclass' tag='li'>
								<div class="membership_item_cont">
									<img src="/static/img/Group%2014.png">
									<p>预约管理</p>
								</div>
							</router-link>
							<router-link to='/work/tcustomsources' tag='li'>
								<div class="membership_item_cont">
									<img src="/static/img/jw4.png" class="ziyuan">
									<p>客户资料库</p>
								</div>
							</router-link>
							<li>
								<div class="membership_item_cont">
									<!-- <img src="../assets/img/a1.png">
									<p>客户管理</p> -->
								</div>
							</li>
							<li>
								<div class="membership_item_cont">
									<!-- <img src="../assets/img/a1.png">
									<p>客户管理</p> -->
								</div>
							</li>
						</ul>
					</div>
				</div>
				
			</van-tab>
			<van-tab title='数据报表'>
				
				<div class="chart_item">
					
					<div class="chart_publick">
						<p>个人</p>
						<van-cell title='销售业绩统计' icon='cluster' is-link to='/datachart/personchart'></van-cell>
					</div>
					<div class="chart_publick">
						<p>门店会籍顾问</p>
						<van-cell title='会籍顾问执行情况' icon='cluster' is-link ></van-cell>
						<van-cell title='会籍卡销售业绩统计' icon='cluster' is-link ></van-cell>
					</div>
					<div class="chart_publick">
						<p>门店教练</p>
						<van-cell title='教练执行概况' icon='cluster' is-link ></van-cell>
						<van-cell title='课程销售业绩统计' icon='cluster' is-link ></van-cell>
						<van-cell title='课程消费课业绩统计' icon='cluster' is-link ></van-cell>
					</div>
					<div class="chart_publick">
						<p>数据分析</p>
						<van-cell title='门店经营看板' icon='cluster' is-link ></van-cell>
						<van-cell title='会籍卡合同分布概况' icon='cluster' is-link ></van-cell>
						<van-cell title='私教课合同分布概况' icon='cluster' is-link ></van-cell>
					</div>
					
					
					
					
				</div>
				
			</van-tab>
		</van-tabs>
		
		<Pfooter :activenum='4'></Pfooter>
	</div>
</template>

<script>
	import Pfooter from '@/components/Pfooter'
	export default {
		name:'work',
		components:{
			Pfooter
		},
		data(){
			return {
				tabactive:0,
			}
		},
		methods:{
			tips(){
				this.$toast('暂无消息')
			},
			kehu(){
				this.$toast('follow')
			}
		},
		mounted(){
			
		},
	}
</script>

<style lang="less" scoped="scoped">
	.right_icon{
		color: #aaa;
		font-size: 20px;
	}
	.membership{
		margin-top: 20px;
		background: #fff;
		h4{
			line-height: 40px;
			padding-left: 15px;
			border-bottom: 1px solid #F2F2F2;
		}
		.membership_item{
			ul{
				display:flex;
				flex: 1;
				justify-content: space-around;
				flex-wrap: wrap;
				li{
					width: 33%;
					border-bottom: 1px solid #f2f2f2;
					border-right: 1px solid #f2f2f2;
					padding-bottom: 10px;
					.membership_item_cont{
						width: 100%;
						img{
							width: 42px;
							display: block;
							margin: 10px auto;
						}
						.ziyuan{
							width: 46px;
							display: block;
							margin: 10px auto;
						}
						p{
							text-align: center;
							font-size: 12px;
							color: #5E5F64;
						}
					}
				}
			}
		}
		
		
		
	}
	.chart_item{
		.chart_publick{
			p{
				padding: 10px;;
			}
		}
	}
</style>
