<template>
	<div class="customyao">
		<!-- 头部引用开始 -->
		<div class="home_header">
			<van-nav-bar class='home_nav' title='选择会员' fixed  @click-left='back()' @click-right='onmore()'>
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<!-- <van-icon class='right_icon' name='邀约管理' slot='right'></van-icon> -->
			</van-nav-bar>
		</div>
		<div class="bgcolor"></div>
		<!-- 头部引用结束 -->
		
		<div class="addinvitation_item">
			
			<div class="addinvitation_search">
				<van-search placeholder='请输入关键词' v-model='search'  >
					<!-- <div slot='action' @click='onsearch()'>搜索</div> -->
				</van-search>
			</div>
			
			<div class="follow_items">
				<van-radio-group v-model='selectarr' >
					<div class="follow_item" v-for="item  in 6"  @click='jump(item)'>
						<van-row>
							<!-- <van-col span='2'>
								<van-radio :name='item' class='checked_xuan' checked-color='#fec949'></van-radio>
							</van-col> -->
							<van-col span='5'>
								<img src='/static/img/touxiang.png' class="photo"/>
							</van-col>
							<van-col span='14'>
								<div class="follow_center">
									<p class="follow_name">沈涛</p>
									<p class="follow_ke van-ellipsis">19329157564</p>
									<!-- <p class="follow_overdue">过期时间：{{item.overdue}}</p> -->
								</div>
							</van-col>
							<van-col span='5'>
								<p class="formal">正式会员</p>
								<p class="qian">李文</p>
							</van-col>
						</van-row>
					</div>
				</van-radio-group>
			</div>
			
			
			
		</div>
			
			
	
		
		
		
	</div>
</template>

<script>
	
	export default {
		name:'customyao',
		
		data(){
			return {
				search:'',
				selectarr:'',
			}
		},
		methods:{
			back(){
				this.$router.go(-1)
			},
			// 打开我们的底部更多的操作
			onmore(){
				// this.$toast('more')
				this.more = true;
			},
			jump(id){
				this.$router.push('/quick/yaoyue/addinvit/'+id)
			}
			
			
		},
		mounted(){
			
		},
	}
</script>

<style lang="less" scoped="scoped">
	.follow_items{
		.checked_xuan{
			text-align: right;
			line-height: 40px;
		}
		.follow_item{
			height: 60px;
			border-bottom: 1px solid #ddd;
			padding:10px 0px;
			background:#fff;
			.photo{
				display: block;
				width: 52px;
				margin: 5px auto;
				border-radius: 100%;
			}
		}
		.follow_center{
			.follow_name{
				font-weight: bold;
				font-size: 16px;
				margin-top: 9px;
			}
			.follow_ke{
				font-size: 12px;
				color: #aaa;
			}
			.follow_overdue{
				font-size: 12px;
				color: #999;
			}
			
			p{
				line-height: 24px;
			}
		}
		.formal{
			margin-top: 3px;
		}
		.formal,.qian{
			font-size: 12px;
			color: #666;
			line-height: 28px;
			text-align: right;
			padding-right: 10px;;
		}
		
	}
</style>
