<template>
	<div class="addinvit">
		<!-- 头部引用开始 -->
		<div class="home_header">
			<van-nav-bar class='home_nav' title='添加邀约' fixed  @click-left='back()' @click-right='edit()'>
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<!-- <van-icon class='right_icon' slot='right'>修改</van-icon> -->
			</van-nav-bar>
		</div>
		<div class="bgcolor"></div>
		<!-- 头部引用结束 -->
		
		<div class="invitation_item">
			
			<div class="detail">
				<van-cell-group>
					<van-field label='邀约人'  v-model='name' input-align='right' placeholder='客户姓名'></van-field>
					<!-- <van-field label='邀约类型'  v-model='type' input-align='right' disabled='true' placeholder='到店体验' is-link @click='typeselect'></van-field> -->
					<van-cell title='邀约类型'  :value='type'  is-link @click='typeselect'></van-cell>
					<van-cell title='邀约时间'  :value='time'  is-link  @click='timeselect'></van-cell>
					<van-cell title='到访门店'  :value='address'  is-link  @click='addressselect'></van-cell>
				</van-cell-group>
			</div>
			
			<div class="detail detail_padding">
				<van-cell-group>
				   <van-cell title="邀约备注"  />
				   <van-field  v-model='note'  placeholder='这是备注消息' ></van-field>
				</van-cell-group>
				<h4></h4>
			</div>
			<van-button class='stop btns_color' size='large' @click='created()'>创建邀约</van-button>
		</div>
			
		<!-- 类型的弹出层 -->
		<van-popup v-model='typeisok' position='bottom'>
			<div class="footer_add" @click="typeadd(1)">到店体验</div>
			<div class="footer_add"  @click="typeadd(2)">体侧</div>
			<div class="footer_add"  @click="typeadd(3)">续费</div>
		</van-popup>
		<!-- 时间选择器 -->
		<van-popup v-model='timeisok' position='bottom'>
			<van-datetime-picker v-model="currentDate" :formatter="formatter" type="datetime" :min-date="minDate" :max-date="maxDate" @change='changetime' @cancel='oncancel' @confirm='onconfirm' />
		</van-popup>
		<!-- 地址选择器 -->
		<van-popup v-model='addressisok' position='bottom'>
			<div class="footer_add" @click="selectadd('环球金融会所')">环球金融会所</div>
			<div class="footer_add" @click="selectadd('正大店')">正大店</div>
			<div class="footer_add" @click="selectadd('池州艺阳健身会所')">池州艺阳健身会所</div>
		</van-popup>
		
		
		
	</div>
</template>

<script>
	
	export default {
		name:'addinvit',
		
		data(){
			return {
				name:'',
				type:'到店体验',		//类型
				time:'选择时间',        //时间
				address:'环球金融会所',     //地址选择
				note:'',        //备注
				editisok:true,  
				
				typeisok:false,  
				timeisok:false,
				addressisok:false,
				minDate:new Date(),
				maxDate:new Date(2099, 12, 31),
				currentDate:new Date(),
			}
		},
		methods:{
			back(){
				this.$router.go(-1)
			},
			// 打开我们的底部更多的操作
			edit(){
				// this.$toast('more')
				this.editisok = false
			},
			
			typeselect(){
				this.typeisok = true
			},
			typeadd(val){
				this.typeisok =false;
				console.log(val)
				this.type = val
			},
			timeselect(){
				this.timeisok = true
			},
			addressselect(){
				this.addressisok = true
			},
			changetime(picker,value,index){
				// 暂不处理
				// console.log(picker.getValues())
				
				// 去掉中文
				var time = picker.getValues()
				var reg = /[\u4e00-\u9fa5]/g;
				
				this.time = time[0].replace(reg,'')+'-'+ time[1].replace(reg,'')+'-'+ time[2].replace(reg,'')+' '+time[3].replace(reg,'')+':'+time[4].replace(reg,'')
			},
			onconfirm(value){
				console.log(value)
				this.timeisok = false
				
			},
			oncancel(){
				this.timeisok =false;
			},
			formatter(type, value) {
			  if (type === 'year') {
				return `${value}年`;
			  } else if (type === 'month') {
				return `${value}月`
			  } else if (type === 'day') {
			  	return `${value}日`
			  }else if (type === 'hour') {
			  	return `${value}时`
			  }else if (type === 'minute') {
			  	return `${value}分`
			  }
			  return value;
			},
			
			selectadd(value){
				this.address = value
				this.addressisok= false
			},
			
			
			created(){
				// 发送
			},
			
		},
		mounted(){
			
		},
	}
</script>

<style lang="less" scoped="scoped">
	.right_icon{
		font-size: 14px;
	}
	.detail{
		margin-top: 16px;
		.van-cell{
			border-bottom: 1px solid #efefef;
		}
	}
	
	.stop{
		position: fixed;
		width: 90%;
		height: 50px;
		bottom: 10px;
		box-sizing: border-box;
		left: 5%;
		color: #fff;
		font-size: 16px;
	}
	.detail_padding{
		padding: 10px 0px;
		background: #fff;
		.van-cell{
			border-bottom: 0px solid #efefef;
		}
	}
</style>
