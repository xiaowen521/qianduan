<template>
	<div class="yuelesson">
		<!-- 头部引用开始 -->
		<div class="home_header">
			<van-nav-bar class='home_nav' title='预约私教课' fixed  @click-left='back()' @click-right='onmore()'>
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<!-- <van-icon class='right_icon' name='ellipsis' slot='right'></van-icon> -->
			</van-nav-bar>
		</div>
		<!-- <div class="bgcolor"></div> -->
		<!-- 头部引用结束 -->
		
		<div class="tyue_item">
			
			<div class="tyue_xuanze">
				<van-radio-group v-model="radio" >
					<!-- <template v-for="item in 3"> -->
						<div :class=" radio == '' || radio == 1 ?  'xuanze_item' :  'none'  ">
							<van-row @click='changes(1)'>
								<van-col span='3'>
									<van-radio name='1' checked-color='#FEC949' class='xuan_radio'  ></van-radio>
								</van-col>
								<van-col span='21'>
									<div class="tyue_right">
										<h4>课程名称<span class="price">￥1999.00</span></h4>
										<p>到期时间：2019-01-09<span>剩余10节</span></p>
									</div>
								</van-col>
							</van-row>
						</div>
					<!-- </template> -->
					
					<div :class=" radio == '' || radio == 2 ? 'xuanze_item' : 'none' ">
						<van-row  @click='changes(2)' >
							<van-col span='3'>
								<van-radio name='2' checked-color='#FEC949' class='xuan_radio' clickable ></van-radio>
							</van-col>
							<van-col span='21'>
								<div class="tyue_right">
									<h4>课程名称<span class="price">￥1999.00</span></h4>
									<p>到期时间：2019-01-09<span>剩余11节</span></p>
								</div>
							</van-col>
						</van-row>
					</div>
					<div :class=" radio == '' || radio == 3 ? 'xuanze_item' : 'none' ">
						<van-row  >
							<van-col span='3'>
								<van-radio name='3' checked-color='#FEC949' class='xuan_radio' clickable  @click='changes(3)'></van-radio>
							</van-col>
							<van-col span='21'>
								<div class="tyue_right">
									<h4>课程名称<span class="price">￥1999.00</span></h4>
									<p>到期时间：2019-01-09<span>剩余12节</span></p>
								</div>
							</van-col>
						</van-row>
					</div>
				</van-radio-group>
				
			</div>
			
			
		</div>
		
		
		<div class="">
			
			
			
			
		</div>
		
		
		
		
		
	</div>
</template>

<script>
	
	export default {
		name:'yuelesson',
		
		data(){
			return {
				radio:'',
				zhong:[1,2,3],
			}
		},
		methods:{
			back(){
				this.$router.go(-1)
			},
			// 打开我们的底部更多的操作
			onmore(){
				// this.$toast('more')
				this.more = true;
			},
			next(){
				this.$router.push('/work/tentry2')
			},
			changes(){
				console.log(this.checkbox)
				this.zhong = [];
				this.zhong.push(this.checkbox)
				
			}
			
			
		},
		mounted(){
			
		},
	}
</script>

<style lang="less" scoped="scoped">
	.tyue_xuanze{
		padding: 0px 15px;
		.xuanze_item{
			padding: 10px 0px;
			border-bottom: 1px solid #f2f2f2;
			.tyue_right{
				h4{
					font-size: 16px;
					color: #303034;
					line-height: 30px;
					span{
						float: right;
					}
				}
				p{
					font-size: 12px;
					color: #898A92;
					line-height: 30px;
					span{
						float: right;
					}
				}
				
			}
			.xuan_radio{
				line-height: 40px;
			}
		}
	}
</style>
