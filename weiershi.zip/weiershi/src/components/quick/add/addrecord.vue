<template>
	<div class="addrecord">
		
		<div class="home_header">
			<van-nav-bar class='home_nav' title='添加联系记录' fixed @click-left='back()' >
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<!-- <van-icon class='right_icon' name='wap-home' slot='right'></van-icon> -->
			</van-nav-bar>
		</div>
		
		<div class="contact_way">
			<h4>联系方式</h4>
			<div class="contact_btns">
				<van-button :class="[contact ==1 ? 'active' : 'nomarl' ]" @click='change_contact(1)'>电 话</van-button>
				<van-button :class="[contact ==2 ? 'active' : 'nomarl' ]"  @click='change_contact(2)'>微 信</van-button>
				<van-button :class="[contact ==3 ? 'active' : 'nomarl' ]" @click='change_contact(3)'>当面沟通</van-button>
				<van-button :class="[contact ==4 ? 'active' : 'nomarl' ]" @click='change_contact(4)'>Q Q</van-button>
				<van-button :class="[contact ==5 ? 'active' : 'nomarl' ]" @click='change_contact(5)'>短 信</van-button>
				<van-button :class="[contact ==6 ? 'active' : 'nomarl' ]" @click='change_contact(6)'>其 他</van-button>
			</div>
		</div>
		
		<div class="contact_matter">
			<h4>事项</h4>
			<div class="contact_itme">
				<van-cell-group>
					<van-cell :title='mattertitle' is-link @click='change_matter'></van-cell>
						
					<template v-if="others">
						<van-field placeholder='请输入事项' v-model='others_way'></van-field>
					</template>
				</van-cell-group>
			</div>
			
		</div>
		
		<div class="contact_way">
			<h4>联系方式</h4>
			<div class="contact_btns contact_two">
				<van-button :class="[contacts ==1 ? 'active' : 'nomarl' ]" @click='change_contacts(1)'>达成</van-button>
				<van-button :class="[contacts ==2 ? 'active' : 'nomarl' ]"  @click='change_contacts(2)'>未达成</van-button>
				
			</div>
		</div>
		
		<!-- 底部的确定按钮 -->
		<div class="footer_bts">
			<van-button :disabled='disabled_isok' class='sure_btn' size='large' @click='sure()'>确认</van-button>
		</div>
		<!-- 底部选择栏选择开始 -->
		
		<van-popup v-model='select' position="bottom" >
			<div class="picker_bottoms">
				<van-picker show-toolbar :columns='columns' @change='onchange' title='事项' @cancel='oncancel' @confirm ='onconfirm'></van-picker>
			</div>
		</van-popup>
		<!-- 底部选择栏选择结束 -->
		
	</div>
</template>

<script>
	export default {
		name: 'addrecord',
		components: {
			
		},
		data() {
			return {
				contact:1,				//这个是我们的头部六个按钮的选择
				contacts:1,          //这个是我们是否达成的操作
				mattertitle:'预约',  //默认的事项标题
				others:false,      //默认的我们出其他外  都不显示
				select:false,      //控制我们下面弹出层的选择的开关
				columns:['预约', '瘦身', '游泳', '健身操', '其他'],
				disabled_isok:false,
				others_way:'',       //绑定我们的其他里面的数据
			}
		},
		methods: {
			back() {
				this.$router.go(-1)
			},
			home() {
				console.log(1)
				this.$router.push('/')
			},
			change_contact(value){
				this.contact = value
			},
			// 是否达成的操作
			change_contacts(value){
				this.contacts = value
			},
			// 点击事项的时候我们做的操作
			change_matter(){
				this.select = true
			},
			onchange(picker, value, index){
				// 注意 我们使用的这个事件的时候不要用 （）  @change='onchange' 而不是  @change='onchange（）'
				// this.$toast(value);
				// this.mattertitle = value;
			},
			onconfirm(value,index){
				 // this.$toast(value);
				 this.select = false;
				 this.mattertitle = value;
				 if(value== '其他'){
					 this.others = true
				 }else{
					this.others = false 
				 }
			},
			oncancel(){
				
			},
			sure(){
				if(this.mattertitle=='其他' && this.others_way == ''){
					this.$toast('请填写事项中的事由')
				}else{
					this.disabled_isok=true;
					this.$toast.loading('提交中')
					this.$axios({
						method:'post',
						url:'/api/contact',
						data:{
							contact:this.contact,
							contacts:this.contacts
						}
					}).then((res)=>{
						console.log(res.data)
						if(res.data=='加油'){
							this.$toast(res.data)
						}else{
							this.$toast('棒棒哒')
						}
					}).catch((err)=>{
						console.log(err)
					})
				}
				

			}
			
		},
		mounted() {
			
			
	
		},
	
	}
</script>

<style lang="less" scoped="scoped">
	.home_nav {
		box-shadow: 0px 0px 15px #f0f0f0;
		.home-left-nav {
			color: #000000;
			vertical-align: middle;
			font-size: 14px;
		
			&:before {
				vertical-align: -2px;
			}
		}
		.right_icon {
			color: #000;
			font-size: 18px;
		}
	}
	.contact_way{
		padding: 10px;
		h4{
			line-height: 35px;
			font-size: 14px;
		}
		.contact_btns{
			display: flex;
			flex: 1;
			justify-content: space-between;
			flex-wrap: wrap;
			.van-button{
				width: 25%;
				margin-bottom: 10px;
				margin: 10px;
			}
			.active{
				background: #efc949;
				color: #fff;
				border: 0px;
			}
			.nomarl{
				background: #f5f5f5;
				border: 0px;
			}
		}
		.contact_two{
			justify-content: left;
		}
		
	}
	.contact_matter{
		padding: 10px;
		h4{
			line-height: 35px;
			font-size: 14px;
		}
	}
	.footer_bts{
		padding: 10px;
		position: relative;
		margin-top: 30px;
		.sure_btn{
			background: linear-gradient(to right,#ffc004,#ff9559);
			border-radius: 5px;
			color: #fff;
		}
	}
</style>
