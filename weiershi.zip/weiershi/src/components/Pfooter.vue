<template>
	<div class="pfooter">
		<div class="static_height"></div>
		<div class="footer_nav">
			<ul>
				<router-link to='/' :class="[ activenums == 1 ? 'active' :'']" >
					<van-icon name='calender-o' size='25px'></van-icon>
					<p>日程</p>
				</router-link>
				<router-link to='/train' :class="[ activenums == 2 ? 'active' :'']" >
					<van-icon name='bar-chart-o' size='25px'></van-icon>
					<p>培训</p>
				</router-link>
				<a href="javascript:void(0)"  :class="[ activenums == 3 ? 'active' :'' ,'center']"  @click="add()">
					<van-icon name='plus' size='25px'></van-icon>
					
				</a>
				<router-link to='/work' :class="[ activenums == 4 ? 'active' :'']" >
					<van-icon name='records' size='25px'></van-icon>
					<p>工作</p>
				</router-link>
				<router-link to='/mine' :class="[ activenums == 5 ? 'active' :'']" >
					<van-icon name='user-o' size='25px'></van-icon>
					<p>我的</p>
				</router-link>
				
			</ul>
		</div>
		
		
		<div class="add" v-if="addisok">
			<ul class="addul">
				<router-link to='/work/addcustom' tag='li' >
					<div class="add_item">
						<img src="../assets/img/a1.png">
						<p>添加新用户</p>
					</div>
				</router-link>

				<router-link to='/quick/add/customlist' tag='li' >
					<div class="add_item">
						<img src="../assets/img/a2.png">
						<p>联系记录</p>
					</div>
				</router-link>
				<router-link to='/quick/yaoyue/customyao' tag='li' >
					<div class="add_item">
						<img src="../assets/img/a3.png">
						<p>邀请客户</p>
					</div>
				</router-link>
				<router-link to='/quick/yuyue/customyue' tag='li' >
					<div class="add_item">
						<img src="../assets/img/a4.png">
						<p>预约私教课</p>
					</div>
				</router-link>
				<router-link to='/quick/tice/customtice' tag='li' >
					<div class="add_item">
						<img src="../assets/img/a5.png">
						<p>体侧记录</p>
					</div>
				</router-link>
				<router-link to='/quick/schedule/addschedule' tag='li' >
					<div class="add_item">
						<img src="../assets/img/a6.png">
						<p>日程</p>
					</div>
				</router-link>
				
			</ul>
			
			<div class="add_close" >
				<van-icon name='cross' @click='close()'></van-icon>
			</div>
			
		</div>
		
	</div>
</template>

<script>
	export default {
		name:'Pfooter',
		props:['activenum'],

		data(){
			return {
				activenums: this.activenum,
				addisok:false,
			}
		},
		computed:{
			
		},
		methods:{
			add(){
				this.addisok = true
			},
			close(){
				this.addisok = false
			}
		},
		mounted:function(){
			// console.log(this.activenums)
		},
		created(){
			var token = this.$store.state.token
			// console.log(token)
			var tokens = localStorage.getItem('token')
			// var tokens = localStorage.removeItem('token')
			// console.log(tokens)
			if(tokens == '' || tokens == undefined){
				this.$router.replace('/login')
			}
		}
	}
</script>

<style lang="less" scoped="scoped">
	.footer_nav{
		position: fixed;
		bottom: 0px;
		left: 0px;
		height: 50px;
		z-index: 1111;
		background: #fff;
		color: #323232;
		width: 100%;
		box-shadow: 0px -5px 35px #ddd; 
		ul{
			display: flex;
			justify-content:space-around;
			 flex: 1;
			 width: 100%;
			.center{
				position: relative;
				display: block;
				top: -30px;
				width: 220px;
				height: 45px;
				line-height: 58px;
				color: #fff;
				background: #ffa833;
				border: 10px solid #fff;
				border-radius: 100%;
			}
			 a{
				 width: 100%;
				 text-align: center;
				 color: #323232;
				 padding-top: 3px;
				 p {
					font-size: 12px;
				 }
			 }
			 a.active{
				 width: 100%;
				 text-align: center;
				 color: #ffa833;
				 p {
					font-size: 12px;
					
				 }
			 }
		}
		
	}
	.add{
		position: fixed;
		width: 100%;
		height: 100%;
		top: 0px;
		z-index: 2222;
		left: 0px;
		background: rgba(255, 255, 255, 0.95);
		.addul{
			display: flex;
			flex: 1;
			width: 100%;
			justify-content: space-around;
			flex-wrap: wrap;
			position: absolute;
			bottom: 50px;
			width: 100%;
			li{
				width: 33.33%;
				margin-bottom: 15px;
				.add_item{
					width: 100%;
					img{
						width: 50%;display: block;
						margin: 10px auto;
					}
					p{
						text-align: center;
						font-size: 14px;
					}
				}
			}
		}
		.add_close{
			position: absolute;
			bottom: 20px;
			text-align: center;
			width: 100%;
			font-size: 18px;
		}
	}

</style>
