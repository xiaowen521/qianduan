<template>
	<div class="changephone">
		<!-- 头部引用开始 -->
		<div class="home_header">
			<van-nav-bar class='home_nav' title='关于' fixed @click-left='back()' >
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<!-- <van-icon class='right_icon' name='wap-home' slot='right'></van-icon> -->
			</van-nav-bar>
		</div>
		
		<!-- 头部引用结束 -->
		
		<div class="about">
			<img src="../../assets/img/logo.png" class="logoimg">
			<p>威尔仕健身成立于1996年，至今在全国范围内已拥有超过115+家直营专业健身俱乐部，会员人数超过50万。威尔仕立足于健身产业，不仅仅秉承健身这一简单理念，而是力求将健康生活方式带来中国，将健康理念渗透到您的工作及生活当中。为您启动科学的健身模式，使您的健身效果事半功倍。</p>
			<p>高效的俱乐部运行环境和专业的健康知识背景将伴随您未来全新的健康生活目标。专业、诚信、服务是威尔仕永远的追求。</p>
			<p>威尔仕希望重新定义中国健身行业的标准，推动健康生活产业的发展。</p>

		</div>
		
		
	</div>
</template>

<script>
	export default {
		name:'about',
		data(){
			return {
				
			}
		},
		computed:{
			
		},
		methods:{
			back() {
				this.$router.go(-1)
			},
			
		},
		monuted(){
			
		}
	}
</script>

<style lang="less" scoped="scoped">
	.about{
		padding: 20px;
		.logoimg{
			display: block;
			margin: 10px auto;
		}
		p{
			text-indent: 2em;
			text-align: justify;
			margin-bottom: 20px;
			font-size: 14px;
			line-height: 24px;
			color: #5E5F64;
		}
	}
</style>
