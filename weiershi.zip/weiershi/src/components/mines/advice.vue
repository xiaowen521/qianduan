<template>
	<div class="changephone">
		<!-- 头部引用开始 -->
		<div class="home_header">
			<van-nav-bar class='home_nav' title='app意见反馈' fixed @click-left='back()' >
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<!-- <van-icon class='right_icon' name='wap-home' slot='right'></van-icon> -->
			</van-nav-bar>
		</div>
		<!-- 头部引用结束 -->
		
		<div class="advice">
			<p>您好，如果您对员工APP有任何建议或问题,希望您可以在这里反馈给我们</p>
			<van-field  placeholder='填写您的建议或问题' class='advice_area' v-model='advice'></van-field >
			<van-button  size="large"  class='send'  @click='nextbu'>提交</van-button>
		</div>
		
		
	</div>
</template>

<script>
	export default {
		name:'advice',
		data(){
			return {
				advice:'',
			}
		},
		computed:{
			
		},
		methods:{
			back() {
				this.$router.go(-1)
			},
			
			nextbu(){
				if(this.advice == ''){
					this.$toast('请输入建议')
				}else{
					this.$axios({
						url:'/api/mine/changephonetwo',
						method:'post',
						data:{
							advice:this.advice,
							
						}
					}).then((res)=>{
						console.log(res)
						this.$toast("更换成功")
					}).catch((err)=>{
						console.log(err)
					})
				}
			}
		},
		monuted(){
			
		}
	}
</script>

<style lang="less" scoped="scoped">
	.advice{
		padding: 15px;
		p{
			line-height: 25px;
			font-size: 12px;
			margin-bottom: 10px;
		}
		.advice_area{
			height: 200px;
			border: 1px solid #ddd;
			background: #f5f5f5;
			border-radius:8px; 
		}
		.send{
			margin-top: 50px;
			background: linear-gradient(to right ,#ffc200 ,#ff9558);
			color: #fff;
		}
	}
</style>
