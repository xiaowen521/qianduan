<template>
	<div class="changephone">
		<!-- 头部引用开始 -->
		<div class="home_header">
			<van-nav-bar class='home_nav' title='更换手机号' fixed @click-left='back()' >
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<!-- <van-icon class='right_icon' name='wap-home' slot='right'></van-icon> -->
			</van-nav-bar>
		</div>
		
		<!-- 头部引用结束 -->
		
		<div class="change">
			
			<van-field  placeholder='请输入手机号' class='phone' v-model='phone'></van-field >
			
			<van-field  placeholder='请输入验证码' class='code' v-model='code'>
				<van-button slot="button" size="small"  class='code_btn' :disabled='switch_code' @click='send_code'>{{code_text}}</van-button>
			</van-field >
				
			<van-button  size="large"  class='send' :disabled='sendisok' @click='nextbu'>下一步{{next}}</van-button>

		</div>
		
		
	</div>
</template>

<script>
	export default {
		name:'changephone',
		data(){
			return {
				phone:'',
				code:'',
				code_text:'请输入验证码',
				switch_code:false,
				sendisok:true,
			}
		},
		computed:{
			next(){
				if(this.phone !='' && this.code!=''){
					this.sendisok = false
				}else{
					this.sendisok = true
				}
			}
		},
		methods:{
			back() {
				this.$router.go(-1)
			},
			send_code(){
				this.switch_code = true;
				var phonereg = /^[1][3,4,5,7,8][0-9]{9}$/;
				if(this.phone == ''  ){
					this.$toast('请填写手机号')
					this.switch_code = false;
				}else if( !phonereg.test(this.phone)){
					this.$toast('请价差手机号是否正确')
					this.switch_code = false;
				}else{
					let  times= 60 ;
					let that = this
					var smalltimes = setInterval(function(){
						times--;
						// console.log(times)
						if(times<=0){
							clearInterval(smalltimes)
							that.code_text='重新获取'
							that.switch_code = false;
						}else{
							that.code_text=times
						}
						
					},1000)
					
					this.$axios({
						url:'/api/changephone',
						method:'get',
						params:{
							phone:this.phone
						}
					}).then((res)=>{
						console.log(res)
						this.$toast("验证码为"+res.data)
					}).catch((err)=>{
						console.log(err)
					})
				}
			},
			nextbu(){
				this.$router.push('/mine/changephone2')
			}
		},
		monuted(){
			
		}
	}
</script>

<style lang="less" scoped="scoped">
	.change{
		padding:30px 20px;
		.phone{
			background: #f2f2f2;
			
		}
		.code{
			margin: 20px 0px;
			background: #f2f2f2;
			
		}
		.code_btn{
			background: linear-gradient(to right ,#ffc200 ,#ff9558);
			color: #fff;
		}
		.send{
			margin-top: 20px;
			background: linear-gradient(to right ,#ffc200 ,#ff9558);
			color: #fff;
		}
	}
</style>
