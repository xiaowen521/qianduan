<template>
	<div class="myaddress">
		<!-- 头部引用开始 -->
		<div class="home_header">
			<van-nav-bar class='home_nav' title='体侧详情' fixed @click-left='back()'>
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<!-- <van-icon class='right_icon' name='wap-home' slot='right'></van-icon> -->
			</van-nav-bar>
		</div>
		<!-- <div class="bgcolor"></div> -->

		<ve-bmap :settings="chartSettings" :series="chartSeries" :tooltip="chartTooltip" :after-set-option-once="afterSet">

		</ve-bmap>



	</div>
</template>
<!-- <script src="https://api.map.baidu.com/api?v=2.0&ak=key"></script> -->
<script>
	
	export default {
		name: 'myaddress',
		data() {

			this.chartSettings = {
				key: 'oBvDtR6nzWtVchkY4cLHtnah1VVZQKRK',
				bmap: {
					center: [120.14322240845, 30.236064370321],
					zoom: 14,
					roam: true,
					mapStyle: {}
				}
			}
			this.chartTooltip = {
				show: true
			}
			return {
				chartSeries: [{
					type: 'scatter',
					coordinateSystem: 'bmap',
					data: [
						[120.14322240845, 30.236064370321,1], // 经度，维度，value，...
					]
				}]
			}
		},
		computed: {

		},
		methods: {
			back() {
				this.$router.go(-1)
			},
			afterSet: function (echarts) {
				var bmap = echarts.getModel().getComponent('bmap').getBMap()
				bmap.addControl(new window.BMap.MapTypeControl())
			  }
	
		},
		monuted() {

		}
	}
</script>

<style lang="less" scoped="scoped">



</style>
