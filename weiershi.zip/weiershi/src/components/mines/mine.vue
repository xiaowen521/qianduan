<template>
	<div class="mine">
		
		<div class="mine_header">
			<van-row>
				<van-col span='6'>
					<img :src="photo" class="photo">
					<!-- <img src="../../assets/img/a1.png"> -->
					<van-uploader :after-read="onRead" class='mine_upload'>
						<van-icon name='photograph'></van-icon>
					</van-uploader>
				</van-col>
				<van-col span='18'>
					<div class="mine_header_right">
						<h4>员工姓名<span>
						<!-- <van-icon name='diamond-o' ></van-icon>店长 -->
						<img src="../../../static/img/dianz.png">
						</span></h4>
						<p>ZDF645456</p>
					</div>
				</van-col>
			</van-row>
		</div>
		<div class="bgcolor"></div>
		
		<div class="mine_cont">
			<h4>基础</h4>
			<div class="jichu">
				<van-cell-group >
					<van-cell title='更换手机号' icon='phone' class='icon_left' is-link to='/mine/changephone'></van-cell>
					<van-cell title='更换密码' icon='bag' class='icon_left' is-link to='/mine/changepsd'></van-cell>
				</van-cell-group>
			</div>
			<h4>关于</h4>
			<div class="about">
				<van-cell-group >
					<van-cell title='app意见反馈' icon='edit' class='icon_left' is-link to='/mine/advice'></van-cell>
					<van-cell title='关于我们' icon='label' class='icon_left' is-link to='/mine/about'></van-cell>
					<!-- <van-cell title='地图' icon='label' class='icon_left' is-link to='/mine/myaddress'></van-cell> -->
				</van-cell-group>
			</div>
			<div class="exit">
				<van-button type='danger' size='large'>退出登录</van-button>
			</div>
		</div>
		
		<pfooter :activenum='5'></pfooter>
	</div>
</template>

<script>
	import Pfooter from '@/components/Pfooter'
	export default {
		name:'mine',
		components:{
			Pfooter
		},
		data(){
			return {
				photo:'/static/img/touxiang.png',
			}
		},
		methods:{
			onRead(file){
				// console.log(file)
				this.$axios({
					url:'/api/uploader',
					method:'post',
					data:{
						value:file.content
					}
				}).then((res)=>{
					// console.log(res)
					this.photo = res.data;
				}).catch((err)=>{
					console.log(err)
				})
			}
		
		},
		mounted(){
			
		},
	}
</script>

<style lang="less" scoped="scoped">
	.mine_header{
		height: 167px;
		padding: 10px;
		background-image: url(/static/img/bg_header.png);
		background-size: 100% 100%;
		position: relative;
		.photo{
			width: 62px;
			margin:45px 15px ;
			border-radius: 50%;
			border: 2px solid #f2f2f2;
		}
		
		.mine_upload{
			position: absolute;
			top: 99px;
			left: 70px;
			color: #fff;
			background: #0000CC;
			width: 23px;
			height: 23px;
			text-align: center;
			line-height: 23px;;
			border-radius:50% ;
		}
		.mine_header_right{
			padding-top: 50px;
			padding-left: 15px;
			color: #fff;
			h4{
				line-height: 30px;
				font-size: 20px;
				font-weight: 500;
				span{
					margin-left: 20px;
					// background: #f9f8a3;
					color: #ebac1a;
					margin-top: 5px;
					// padding: 2px 5px;
					font-size: 12px;
					border-radius: 5px;
					img{
						height: 20px;
					}
					i{
						font-size: 14px;
						vertical-align: -3px;
						margin-right: 3px;
					}
				}
			}
			p{
				font-size: 14px;
				line-height: 30px;
				color: rgba(255, 255, 255, 0.7);
			}
		}
	}
	.mine_cont{
		h4{
			line-height: 35px;
			color: #aaa;
			font-size: 14px;
			padding-left: 10px;
		}
		.exit{
			margin-top: 50px;
		}
	}
	.icon_left{
		color: #303034;
		border-bottom: 1px solid #efefef;
		span{
			padding-left: 10px;
		}
	}
	.exit{
		font-size: 16px;
		.van-button__text{
			font-size: 16px;
		}
	}
</style>
