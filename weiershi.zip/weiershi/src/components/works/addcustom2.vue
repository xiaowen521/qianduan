<template>
	<div class="addcustom2">
		<!-- 头部引用开始 -->
		<div class="home_header">
			<van-nav-bar class='home_nav' title='添加客户' fixed  @click-left='back()' @click-right='more()'>
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<!-- <van-icon class='right_icon' name='bell' slot='right'></van-icon> -->
			</van-nav-bar>
		</div>
		<!-- <div class="bgcolor"></div> -->
		<!-- 头部引用结束 -->
		
		<div class="sort_item">
			<h4>健身诉求 (选填)</h4>
			<div class="sort_flex">
				<van-button v-for='(item ,index) in choosearr' :key=index   :class=" checked.indexOf(item) != -1 ? 'active' :'nomarl'" @click='choose(item)'>{{item}}</van-button>
				
				<!-- <van-button   :class="ischecked==2 ? 'active' :'nomarl'" @click='choose(2)'>技能成长</van-button>
				<van-button   :class="ischecked==3 ? 'active' :'nomarl'"  @click='choose(3)'>运动课程</van-button>
				<van-button   :class="ischecked==4 ? 'active' :'nomarl'"  @click='choose(4)'>局部减肥</van-button>
				<van-button   :class="ischecked==5 ? 'active' :'nomarl'"  @click='choose(5)'>增肌食谱</van-button>
				<van-button   :class="ischecked==6 ? 'active' :'nomarl'"  @click='choose(6)'>减肥食谱</van-button> -->
				<template v-if="checked.indexOf(6) != -1 ">
					<van-field v-model='jian_1' placeholder='请输入' class='border_bottom'></van-field>
				</template>
			</div>
			
		</div>
		<div class="sort_item">
			<h4>客户兴趣 (选填)</h4>
			<div class="sort_flex">
				<van-button   :class=" checkedsex.indexOf(1) != -1 ? 'active' :'nomarl'" @click='choosesexd(1)'>男</van-button>
				<van-button   :class=" checkedsex.indexOf(2) != -1 ? 'active' :'nomarl'" @click='choosesexd(2)'>女</van-button>
				<van-button   :class=" checkedsex.indexOf(3) != -1 ? 'active' :'nomarl'" @click='choosesexd(3)'>女</van-button>
				<van-button   :class=" checkedsex.indexOf(4) != -1 ? 'active' :'nomarl'" @click='choosesexd(4)'>女</van-button>
				<van-button   :class=" checkedsex.indexOf(5) != -1 ? 'active' :'nomarl'" @click='choosesexd(5)'>女</van-button>
				<van-button   :class=" checkedsex.indexOf(6) != -1 ? 'active' :'nomarl'" @click='choosesexd(6)'>女</van-button>
				
				<!-- <van-button   :class="ischecked==2 ? 'active' :'nomarl'" @click='choose(2)'>技能成长</van-button>
				<van-button   :class="ischecked==3 ? 'active' :'nomarl'"  @click='choose(3)'>运动课程</van-button>
				<van-button   :class="ischecked==4 ? 'active' :'nomarl'"  @click='choose(4)'>局部减肥</van-button>
				<van-button   :class="ischecked==5 ? 'active' :'nomarl'"  @click='choose(5)'>增肌食谱</van-button>
				<van-button   :class="ischecked==6 ? 'active' :'nomarl'"  @click='choose(6)'>减肥食谱</van-button> -->
				<template v-if="checkedsex.indexOf(6) != -1 ">
					<van-field v-model='jian_2' placeholder='请输入'  class='border_bottom'></van-field>
				</template>
			</div>
			
		</div>
		
		<div class="sort_item">
			<h4>健身状况 (选填)</h4>
			<div class="sort_flex">
				<van-button v-for='(item ,index) in chooseyi' :key=index   :class=" checkedyi.indexOf(item) != -1 ? 'active' :'nomarl'" @click='chooseyix(item)'>{{item}}</van-button>
				
				<template v-if="checkedyi.indexOf(6) != -1 ">
					<van-field v-model='jian_3' placeholder='请输入'  class='border_bottom'></van-field>
				</template>
			</div>
			
		</div>
		
		<div class="sort_item">
			<h4>健身史 (选填)</h4>
			<div class="sort_flex">
				<van-field v-model='history' placeholder='请输入' class='border_bottom'></van-field>
				
			</div>
			
		</div>
		<div class="sort_item">
			<h4>本次健身计划 (选填)</h4>
			<div class="sort_flex">
				<van-field v-model='planning' placeholder='请输入' class='border_bottom'></van-field>
				
			</div>
			
		</div>
		<div class="sort_item">
			<h4>不买私教课的健身计划 (选填)</h4>
			<div class="sort_flex">
				<van-field v-model='nobuyplan' placeholder='请输入' class='border_bottom'></van-field>
				
			</div>
			
		</div>
		
		
		
		<div class="static_height"></div>
		<div class="footer">
			<van-row gutter="20">
				<van-col span='8'>
					<van-button type='default' size='large' class='footer_reset' @click='prev'>上一步</van-button>
				</van-col>
				<van-col span='16'>
					<van-button type='default' size='large' class='footer_sure' @click='sure'>确认</van-button>
				</van-col>
				
			</van-row>
		</div>
		
	</div>
</template>

<script>
	
	export default {
		name:'addcustom2',
		
		data(){
			return {
				tabactive:0,
				search:'',
				customisok:true,
				
				choosearr:[1,2,3,4,5,6],     //选择健身诉求
				checked:[],                // 选中的健身诉求状态
				
				choosesex:[1,2,3,4,5,6],            //选择客户兴趣
				checkedsex:[],                // 选中的客户兴趣状态
				
				chooseyi:[1,2,3,4,5,6],            //选择健身状况
				checkedyi:[],             // 选中的健身状况状态
				
				history:'',           //健身史
				planning:'',          //本次健身计划
				nobuyplan:'',         //不买健身的计划
				
				jian_1:'',           //健身诉求选填
				jian_2:'',           //客户诉求选填
				jian_3:'',           //健身状况选填
			}
		},
		methods:{
			back(){
				this.$router.go(-1)
			},
			more(){
				this.$toast('more')
			},
			choose(id){
				// 判断我们选择的数组中是否有 传来的 值 如果有责证明我们取消选择   如果没有我们去添加
				if(this.checked.indexOf(id) != -1){
					var sort = this.checked.indexOf(id)
					this.checked.splice(sort,1)
				}else{
					this.checked.push(id)
				}
				
			},
			choosesexd(id){
				// 判断我们选择的数组中是否有 传来的 值 如果有责证明我们取消选择   如果没有我们去添加
				if(this.checkedsex.indexOf(id) != -1){
					var sort = this.checkedsex.indexOf(id)
					this.checkedsex.splice(sort,1)
				}else{
					this.checkedsex.push(id)
				}
				
			},
			chooseyix(id){
				// 判断我们选择的数组中是否有 传来的 值 如果有责证明我们取消选择   如果没有我们去添加
				if(this.checkedyi.indexOf(id) != -1){
					var sort = this.checkedyi.indexOf(id)
					this.checkedyi.splice(sort,1)
				}else{
					this.checkedyi.push(id)
				}
			},
			prev(){
				this.$router.go(-1)
			},
			sure(){
				// 做提交的后台交回并返回
				this.$router.replace('/work/custom')
			}
			
		},
		mounted(){
			
		},
	}
</script>

<style lang="less" scoped="scoped">

	.right_icon{
		font-size: 16px;
		color: #333;
	}
	.sort_item{
		padding:5px 15px;
		.border_bottom{
			border-bottom: 1px solid #efefef;
		}
		h4{
			padding: 15px 0px;
			font-size: 15px;
			color:#303034;
			line-height:22px;
		}
		.sort_flex{
			display: flex;
			flex: 1;
			justify-content: left;
			flex-wrap: wrap;
			.van-button{
				width: 105px;
				margin-bottom: 15px;
				height: 38px;
				line-height: 38px;
				margin: 8px 5px;
			}
			
			
		}
		.active{
			background: #FEC949;
			color: #fff;
			border: 0px;
		}
		.nomarl{
			background: #f5f5f5;
			border: 0px;
		}
	}
	.footer{
		position: fixed;
		bottom: 5px;
		width: 100%;
		padding: 10px;
		box-sizing: border-box;
		font-size: 16px;
		height: 70px;
		.footer_sure{
			background: linear-gradient(314deg,rgba(255,148,92,1) 0%,rgba(255,194,0,1) 100%);
			color: #fff;
			font-size: 16px;
		}
	}
	
</style>
