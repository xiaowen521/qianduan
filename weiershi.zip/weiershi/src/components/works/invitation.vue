<template>
	<div class="invitation">
		<!-- 头部引用开始 -->
		<div class="home_header">
			<van-nav-bar class='home_nav' title='邀约管理' fixed  @click-left='back()' @click-right='add()'>
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<van-icon class='right_icon' name='plus' slot='right'></van-icon>
			</van-nav-bar>
		</div>
		<div class="bgcolor"></div>
		<!-- 头部引用结束 -->
		
		<div class="invitation_item">
			
			<div class="invitation_search">
				<van-search placeholder='请输入会员姓名、手机号' v-model='search'  >
					<!-- <div slot='action' @click='onsearch()'>搜索</div> -->
				</van-search>
			</div>
			
			<div class="invitation_item_block" @click="enterdetail(1)">
				<van-row>
					<van-col span='6'>
						<img src="../../../static/img/touxiang.png" class="invit_photo">
					</van-col>
					<van-col span='18'>
						<div class="invit_item">
							<h4 class="name">廖娟</h4>
							<p class="time">到店时间：08-02 13:00</p>
							<p class="bei">备注：这是备注这是备注这是备注这是备注这是备</p>
						</div>
					</van-col>
				</van-row>
				
			</div>
			<div class="invitation_item_block"  @click="enterdetail(2)">
				<van-row>
					<van-col span='6'>
						<img src="../../../static/img/touxiang.png" class="invit_photo">
					</van-col>
					<van-col span='18'>
						<div class="invit_item">
							<h4 class="name">廖娟</h4>
							<p class="time">到店时间：08-02 13:00</p>
							<p class="bei">备注：这是备注这是备注这是备注这是备注这是备</p>
						</div>
					</van-col>
				</van-row>
				
			</div>
			<div class="invitation_item_block"  @click="enterdetail(3)">
				<van-row>
					<van-col span='6'>
						<img src="../../../static/img/touxiang.png" class="invit_photo">
					</van-col>
					<van-col span='18'>
						<div class="invit_item">
							<h4 class="name">廖娟</h4>
							<p class="time">到店时间：08-02 13:00</p>
							<p class="bei">备注：这是备注这是备注这是备注这是备注这是备</p>
						</div>
					</van-col>
				</van-row>
				
			</div>
			<div class="invitation_item_block"  @click="enterdetail(4)">
				<van-row>
					<van-col span='6'>
						<img src="../../../static/img/touxiang.png" class="invit_photo">
					</van-col>
					<van-col span='18'>
						<div class="invit_item">
							<h4 class="name">廖娟</h4>
							<p class="time">到店时间：08-02 13:00</p>
							<p class="bei">备注：这是备注这是备注这是备注这是备注这是备</p>
						</div>
					</van-col>
				</van-row>
				
			</div>
		</div>
			
	
		
		
		
	</div>
</template>

<script>
	
	export default {
		name:'invitation',
		
		data(){
			return {
				search:'',
			}
		},
		methods:{
			back(){
				this.$router.go(-1)
			},
			// 打开我们的底部更多的操作
			add(){
				// this.$toast('more')
				this.$router.push('/work/addinvitation')
			},
			enterdetail(id){
				this.$router.push('/work/invitationdetail/'+id)
			}
			
			
		},
		mounted(){
			
		},
	}
</script>

<style lang="less" scoped="scoped">
	.invitation_item_block{
		background: #fff;
		padding: 10px;
		border-bottom: 1px solid #efefef;
		.invit_photo{
			width: 52px;
			margin: 10px;
		}
		.invit_item{
			h4{
				font-size: 16px;
				line-height: 22px;
			}
			.time{
				font-size: 14px;
				line-height: 35px;
				color: #5E5F64;
			}
			.bei{
				font-size: 12px;
				line-height: 22px;
				color: #898A92;
			}
			
		}
	}
</style>
