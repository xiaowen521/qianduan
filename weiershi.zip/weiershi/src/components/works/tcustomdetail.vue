<template>
	<div class="customdetail">
		<!-- 头部引用开始 -->
		<div class="home_header">
			<van-nav-bar class='home_nav' title='客户详情' fixed @click-left='back()' @click-right='onmore()'>
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<van-icon class='right_icon' name='ellipsis' slot='right'></van-icon>
			</van-nav-bar>
		</div>
		<!-- <div class="bgcolor"></div> -->
		<!-- 头部引用结束 -->
		<div class="mine_header">
			<van-row>
				<van-col span='24'>
					<img :src="photo" class="photo">
					<!-- <img src="/static/img/touxiang.png"> -->
					<van-icon name='photograph'  class='mine_upload' @click='changephoto()'></van-icon>
					<h4><img src="/static/img/zshy.png"></h4>
				</van-col>

			</van-row>
		</div>
		<div class="bgcolor"></div>
		<!-- 头部引用结束 -->

		<div class="tcustomdetail_item">
			<van-tabs v-model='tabactive'>
				<div class="box_showdom"></div>
				<van-tab title='基本'>

					<div class="custom_base">
						<van-cell-group class='base_block'>
							<van-cell title='手机号' class='base_item'>
								<div slot='right-icon' @click="phone_cell(18158873627)">
									<a href="javascript:void(0)" class="tel">18158873627<img src="/static/img/bluephone.png"></a>
								</div>
							</van-cell>
							<van-cell title='性别' value='男' class='base_item'></van-cell>
							<van-cell title='性信息来源别' value='w到访' class='base_item'></van-cell>
						</van-cell-group>

						<van-cell-group class='base_block'>
							<van-cell title='身份证号' value='41130234550813542x' class='base_item'></van-cell>
							<van-cell title='生日' value='1999-08-13' class='base_item'></van-cell>
							<van-cell title='客户分类' value='高意向' class='base_item'></van-cell>
						</van-cell-group>

						<van-cell-group class='base_block'>
							<van-cell title='状态' value='正式会员' class='base_item'></van-cell>
							<van-cell title='所属部门' value='环球金融会所' class='base_item'></van-cell>
							<van-cell title='环球金融会所' value='程英杰' class='base_item'></van-cell>
							<van-cell title='跟进教练' value='程英剧' class='base_item'></van-cell>
							<van-cell title='入会时间' value='2018-08-13' class='base_item'></van-cell>
							<van-cell title='剩余有效期' value='200天' class='base_item'></van-cell>
						</van-cell-group>
						<van-cell-group class='base_block'>
							<van-cell title='备注'></van-cell>
							<van-field type="textarea" autosize value='这是备注信息这是备注信息这是备注信息这是备注信息 这是备注信息'></van-field>
						</van-cell-group>
						<van-cell-group class='base_block'>
							<van-cell title='健身诉求'></van-cell>
							<div class="btns_item">
								<van-button class='btn_btns'>减脂</van-button>
							</div>
						</van-cell-group>
						<van-cell-group class='base_block'>
							<van-cell title='客户兴趣'></van-cell>
							<div class="btns_item">
								<van-button class='btn_btns'>有氧器械</van-button>
								<van-button class='btn_btns'>瑜伽普拉提</van-button>
								<van-button class='btn_btns'>减脂</van-button>
							</div>
						</van-cell-group>
						<van-cell-group class='base_block'>
							<van-cell title='健康状态'></van-cell>
							<div class="btns_item">
								<van-button class='btn_btns'>良好</van-button>
							</div>
						</van-cell-group>
						<van-cell-group class='base_block'>
							<van-cell title='健身史'></van-cell>
							<van-field type="textarea" autosize value='这是健身这是健身这是健身这是健身这是健身这是健身 这是健身'></van-field>
						</van-cell-group>
						<van-cell-group class='base_block'>
							<van-cell title='本次健身计划'></van-cell>
							<van-field type="textarea" autosize value='这是健身这是健身这是健身这是健身这是健身这是健身 这是健身'></van-field>
						</van-cell-group>
						<van-cell-group class='base_block'>
							<van-cell title='不买私教的健身方案'></van-cell>
							<van-field type="textarea" autosize value='这是健身这是健身这是健身这是健身这是健身这是健身 这是健身'></van-field>
						</van-cell-group>
					</div>

				</van-tab>
				<van-tab title='联系'>
					<div class="custom_contact">

						<div class="constant_item">
							<van-row>
								<van-col span='4'>
									<img src="/static/img/yuan1.png">
								</van-col>
								<van-col span='20'>
									<div class="constant_item_right">
										<h4>员工姓名<span class="time">2018-08-13 13:00</span></h4>
										<p>祝贺会员生日快乐<span class="iscontact">未达成</span></p>
									</div>
								</van-col>
							</van-row>
						</div>
						<div class="constant_item">
							<van-row>
								<van-col span='4'>
									<img src="/static/img/yuan2.png">
								</van-col>
								<van-col span='20'>
									<div class="constant_item_right">
										<h4>员工姓名<span class="time">2018-08-13 13:00</span></h4>
										<p>祝贺会员生日快乐<span class="iscontactok">达成</span></p>
									</div>
								</van-col>
							</van-row>
						</div>
						
						
					</div>
					
					<div class="static_height"></div>
					<div class="footer_add">
						<img src="/static/img/addcontact.png" @click="jump()">
						<p>添加联系记录</p>
					</div>
				</van-tab>
				<van-tab title='订单'>
					<div class="custom_order">
						
						<div class="order_item">
							<van-row>
								<van-col span='4'>
									<img src="/static/img/ka.png">
								</van-col>
								<van-col span='20'>
									<div class="order_item_right">
										<h4>会籍卡名称<span class="price">￥1999.00</span></h4>
										<p>到期时间：2019-01-09<span class="time">2018-08-13 13:00</span></p>
									</div>
								</van-col>
							</van-row>
						</div>
						<div class="order_item">
							<van-row>
								<van-col span='4'>
									<img src="/static/img/kecheng.png">
								</van-col>
								<van-col span='20'>
									<div class="order_item_right">
										<h4>课程名称<span class="price">￥1999.00</span></h4>
										<p>到期时间：2019-01-09<span class="time">2018-08-13 13:00</span></p>
									</div>
								</van-col>
							</van-row>
						</div>
						<div class="order_item">
							<van-row>
								<van-col span='4'>
									<img src="/static/img/ka.png">
								</van-col>
								<van-col span='20'>
									<div class="order_item_right">
										<h4>会籍卡名称<span class="price">￥1999.00</span></h4>
										<p>到期时间：2019-01-09<span class="time">2018-08-13 13:00</span></p>
									</div>
								</van-col>
								<div class="isfailure">
									<img src="/static/img/isfail.png">
								</div>
							</van-row>
						</div>
						
					</div>
				</van-tab>
				<van-tab title='进店'>
					<div class="custom_enter">
						<div class="enter_item">
							<h4>环球金融会所<img src="/static/img/document.png"> <span class="time">2018-08-13 14:00</span></h4>
						</div>
						<div class="enter_item">
							<h4>环球金融会所 <span class="time">2018-08-13 14:00</span></h4>
						</div>
						<div class="enter_item">
							<h4>环球金融会所 <span class="time">2018-08-13 14:00</span></h4>
						</div>
						<div class="enter_item">
							<h4>环球金融会所<img src="/static/img/document.png"> <span class="time">2018-08-13 14:00</span></h4>
						</div>
						
					</div>
				</van-tab>
				<van-tab title='约课'>
					<div class="custom_lesson">
						
						<div class="lesson_item">
							<h4>魔鬼增肌私教课<span class="time">2018-08-13 13:00</span></h4>
							<p><img src="/static/img/si.png"> <span class="name">程英俊</span></p>
						</div>
						<div class="lesson_item">
							<h4>魔鬼增肌私教课<span class="time">2018-08-13 13:00</span></h4>
							<p><img src="/static/img/free.png"> <span class="name">程英俊</span></p>
						</div>
						<div class="lesson_item">
							<h4>瑜伽基础拉练课<span class="time">2018-08-13 13:00</span></h4>
							<p><img src="/static/img/pay.png"> <span class="name">程英俊</span></p>
						</div>
						
					</div>
					<div class="static_height"></div>
					<div class="footer_add">
						<img src="/static/img/yue.png" @click="jumpyue()">
						<p>预约私教课</p>
					</div>
					
					
				</van-tab>
				
				<van-tab title='体侧'>
					<div class="custom_tice">
						
						<div class="tice_item" @click="entertice()">
							<span class="tice_type">偏瘦</span>
							<span class="tice_fen">55<small>分</small></span>
							<span class="tice_time">2018-08-13 13:00</span>
						</div>
						<div class="tice_item" @click="entertice()">
							<span class="tice_typep ">偏胖</span>
							<span class="tice_fen">85<small>分</small></span>
							<span class="tice_time">2018-08-13 13:00</span>
						</div>
						<div class="tice_item" @click="entertice()">
							<span class="tice_typez">正常</span>
							<span class="tice_fen">75<small>分</small></span>
							<span class="tice_time">2018-08-13 13:00</span>
						</div>
						<div class="tice_item" @click="entertice()">
							<span class="tice_type">偏瘦</span>
							<span class="tice_fen">54<small>分</small></span>
							<span class="tice_time">2018-08-13 13:00</span>
						</div>
						
					</div>
					
					<div class="static_height"></div>
					<div class="footer_add">
						<img src="/static/img/people.png" @click="jumptice()">
						<p>录入体侧数据</p>
					</div>
				</van-tab>

			</van-tabs>

		</div>
		
		<!-- 点击更多的弹窗 -->
		<van-popup v-model='more' position='bottom'>
			<div>
				<div class="footer_nav" @click="morechange">更换会籍顾问</div>
				<div class="footer_nav" @click="morecancel">取消</div>
			</div>
		</van-popup>
		<!-- 点击拍照的图标的弹窗 -->
		<van-popup v-model='photos' position='bottom'>
			<div>
				<div class="footer_nav" @click="takephoto">拍照</div>
				<div class="footer_nav" >
					<van-uploader :after-read="onRead" >上传照片</van-uploader>
				</div>
				
				<div class="footer_nav" @click="photoscancel">取消</div>
			</div>
		</van-popup>
		
		
	</div>
</template>

<script>
	export default {
		name: 'tcustomdetail',

		data() {
			return {
				photo: '/static/img/touxiang.png',   //默认头像
				tabactive: 0,                        //绑定我们切换的切换tabs
				more:false,							 //点击更多图标出现的弹出层
				photos:false    						,//点击我们的拍照图标出现的弹窗
				photo:'/static/img/touxiang.png'
			}
		},
		methods: {
			back() {
				this.$router.go(-1)
			},
			onmore() {
				this.more=true
			},
			//拍照的方法
			takephoto(){
				this.$toast('暂不支持')
			},
			// 点击拍照小图标的方法
			changephoto(){
				this.photos = true;
			},
			//上传的照片
			onRead(value) {
				console.log(value)
				this.photos = false;
				this.photo = value.content;
				// 加上上传的接口
			},
			photoscancel(){
				this.photos = false
			},
			jump(){
				this.$router.push('/work/tcontact')
			},
			jumptice(){
				this.$router.push('/work/tentry')
			},
			// 点击更多里的内容
			morechange(){
				
			},
			morecancel(){
				this.more =false
			},
			// 点击拨打电话出现的
			phone_cell(phone){
				this.$dialog.confirm({
				  title: '是否要拨打电话',
				  confirmButtonText:'拨打',
				  cancelButtonText:'关闭'
				}).then(() => {
				  // on confirm
				  console.log(phone)
				  window.location.href = 'tel://'+phone
				  
				  // 后续操作做不了
				  
				}).catch(() => {
				  // on cancel
				});
			},
			entertice(){
				this.$router.push('/tice')
			},
			jumpyue(){
				this.$router.push('/work/tyue')
			}
					

		},
		mounted() {
			// 注意我们的$route  不是$router 不然得不到值
			var id = this.$route.params.id;

			// 得到id 进行数据操作 ajax 请求

		},
	}
</script>

<style lang="less" scoped="scoped">
	.mine_header {
		height: 150px;
		padding: 10px;
		background-image: url(/static/img/bg_header.png);
		background-size: 100% 100%;
		position: relative;

		.photo {
			display: block;
			width: 62px;
			height: 62px;
			margin: 15px auto 25px;
			border-radius: 50%;
			border: 2px solid #f2f2f2;
		}

		h4 {
			text-align: center;
		}

		.mine_upload {
			position: absolute;
			top: 70px;
			left: 50%;
			margin-left: 15px;
			color: #fff;
			background: #0000CC;
			width: 23px;
			height: 23px;
			text-align: center;
			line-height: 25px;
			;
			border-radius: 50%;
		}
	}

	.box_showdom {
		background: #fff;
		height: 5px;
		margin-bottom: 15px;
		box-shadow: 0px 0px 20px #ddd;
	}

	.custom_base {
		.base_block {
			margin-bottom: 16px;

			.btns_item {
				padding: 10px;

				.btn_btns {
					background: #F5F5F5;
				}
			}

			.base_item {
				.tel {
					color: #969799;
				}

				img {
					vertical-align: -3px;
					margin-left: 8px;
				}
			}
		}
	}

	.custom_contact {
		background: #fff;

		.constant_item {
			height: 84px;
			box-sizing: border-box;
			border-bottom: 1px solid #efefef;
			padding: 18px 10px 14px;

			img {
				width: 52px;
			}

			.constant_item_right {
				h4 {
					margin-bottom: 6px;
					font-size: 16px;

					.time {
						font-size: 12px;
						font-family: PingFangSC-Regular;
						font-weight: 400;
						color: rgba(137, 138, 146, 1);
						line-height: 22px;
						text-align: right;
						float: right;
					}
				}

				p {
					height:22px;
					font-size:14px;
					font-family:PingFangSC-Regular;
					font-weight:400;
					color:rgba(137,138,146,1);
					line-height:22px;
					.iscontact{
						padding:0px 6px;
						color: #FFFFFF;
						background:rgba(137,138,146,0.59);
						font-size: 12px;
						float: right;
						border-radius: 2px;
					}
					.iscontactok{
						padding:0px 6px;
						color: #FFFFFF;
						background:#45C894;
						font-size: 12px;
						float: right;
						border-radius: 2px;
					}
				}
			}
		}
		
	}
	.custom_order{
		background: #fff;
		.order_item {
			height: 84px;
			box-sizing: border-box;
			border-bottom: 1px solid #efefef;
			padding: 18px 10px 14px;
			position: relative;
			img {
				width: 52px;
			}
		
			.order_item_right {
				h4 {
					margin-bottom: 10px;
					font-size: 16px;
		
					.price {
						font-size: 16px;
						font-family: PingFangSC-Regular;
						font-weight: 400;
						color: #303034;
						line-height: 22px;
						text-align: right;
						float: right;
						font-weight:bold;
					}
				}
		
				p {
					height:22px;
					font-size:12px;
					font-family:PingFangSC-Regular;
					font-weight:400;
					color:rgba(137,138,146,1);
					line-height:22px;
					.time{
						font-size: 12px;
						float: right;
					}
					
				}
			}
			.isfailure{
				width: 100%;
				height: 100%;
				position: absolute;
				top: 0px;
				left:0px;
				background: rgba(255, 255,255,0.7);
				img {
					float:right;
					margin: 10px 18px;
					width: 60px;
					background: #fff;
				}
			}
		}
	}
	.custom_enter{
		.enter_item{
			background: #fff;
			height: 52px;
			line-height: 52px;
			border-bottom: 1px solid #efefef;
			padding: 0px 10px;
			img{
				margin-left: 8px;
				vertical-align: -3px;
			}
			.time{
				text-align: right;
				float: right;
				font-size: 12px;
				color: #898A92;
				font-weight: normal;
			}
		}
		
	}
	.custom_lesson{
		background: #fff;
		.lesson_item{
			padding: 0px 16px;
			height: 82px;
			border-top: 1px solid #fff;
			border-bottom: 1px solid #efefef;
			h4{
				margin: 16px 0px;
				font-size: 16px;
				.time{
					float: right;
					font-size: 12px;
					color: #898A92;
					font-weight: normal;
				}
			}
			p{
				.name{
					float: right;
					color: #5E5F64;
					font-size: 12px;
					margin-right: 5px;
				}
			}
		}
	}
	.custom_tice{
		.tice_item{
			height: 52px;
			padding: 5px 16px;
			background: #fff;
			line-height: 52px;
			.tice_type{
				padding: 3px 8px;
				background: #8696ff;
				border-radius: 2px;
				color: #fff;
			}
			.tice_typep{
				padding: 3px 8px;
				background: #ff8479;
				border-radius: 2px;
				color: #fff;
			}
			.tice_typez{
				padding: 3px 8px;
				background: #38c7b0;
				border-radius: 2px;
				color: #fff;
			}
			.tice_fen{
				font-size: 24px;
				color: #303034;
				font-weight:bold;
				margin-left: 10px;
				vertical-align: -3px;
				small{
					font-size: 12px;
					color: #898A92;
					font-weight:normal;
				}
			}
			.tice_time{
				float: right;
				color: #898A92;
				font-size: 12px;
			}
		}
	}
	.footer_nav{
		height: 48px;
		border-bottom: 1px solid #efefef;
		font-size: 16px;
		text-align: center;
		line-height: 48px;
		color: #0A160B;
	}
	.footer_add{
		position: fixed;
		bottom: 10px;
		width: 100%;
		height:70px;
		img{
			box-shadow: 0px 0px 5px #ddd;
			background: #fff;
			display: block;
			margin: 0 auto;
			border-radius: 50%;
		}
		p{
			text-align: center;
			color: #B1B2BC;
			margin: 7px auto;
		}
	}

</style>
