<template>
	<div class="customsources">
		<!-- 头部引用开始 -->
		<div class="home_header">
			<van-nav-bar class='home_nav'  fixed  @click-left='back()' @click-right='onmore()'>
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<div slot='title'>
					<select class="home_title" v-model="selectadds" @change="changeaddress()">
						
						<option :value="item" v-for=" item in arraddress">{{item}}</option>
						<!-- <option value="2">正大店1</option> -->
						<!-- <option value="3">正大店2</option> -->
					</select>
				</div>
				<van-icon class='right_icon' name='ellipsis' slot='right'></van-icon>
			</van-nav-bar>
		</div>
		<div class="bgcolor"></div>
		<!-- 头部引用结束 -->
		
		<div class="custom_item">
			
			<div class="custom_search">
				<van-search placeholder='请输入关键词' v-model='search'  @search='onsearch()' @focus='onsearch()' >
					<!-- <div slot='action' @click='onsearch()'>搜索</div> -->
				</van-search>
			</div>
			
			<!-- 如果点击了 我们的更多中的筛选 那我们就把all 全部屏蔽掉 -->
			<template v-if="all">
			
				<template v-if="customisok">
					<div class="custom_item_listzong">
						<van-tabs v-model='tabactive'>
							<van-tab title='录入时间'>
								<div class="follow_items">
									<div class="follow_item" v-for="item in follows " @click="entercustom(item.id)">
										<van-row>
											<van-col span='5'>
												<img :src='item.photo' class="photo"/>
											</van-col>
											<van-col span='14'>
												<div class="follow_center">
													<p class="follow_name">{{item.name}}</p>
													<p class="follow_ke van-ellipsis">2018-11-06</p>
													<!-- <p class="follow_overdue">过期时间：{{item.overdue}}</p> -->
												</div>
											</van-col>
											<van-col span='5'>
												<p class="formal">潜客</p>
												<p class="qian">许敏</p>
											</van-col>
										</van-row>
									</div>
								</div>
							</van-tab>
							<van-tab>
								<div slot='title'>
									最近联系时间<van-icon name='descending' class='custom_icon'></van-icon>
									
								</div>
								<div class="follow_items">
									<div class="follow_item" v-for="item in follows "  @click="entercustom(item.id)">
										<van-row>
											<van-col span='5'>
												<img :src='item.photo' class="photo"/>
											</van-col>
											<van-col span='14'>
												<div class="follow_center">
													<p class="follow_name">{{item.name}}</p>
													<p class="follow_ke van-ellipsis">2018-11-06 13:00 </p>
												</div>
											</van-col>
											<van-col span='5'>
												<p class="formal">潜客</p>
												<p class="qian">何秀英</p>
											</van-col>
										</van-row>
									</div>
								</div>
							</van-tab>
							<van-tab >
								<div slot='title' style="text-align: right;"  @click='choose()'>
									筛选<van-icon name='filter-o' class='custom_icon'></van-icon>
								</div>
							</van-tab>
							
						</van-tabs>
					</div>
				</template>
				<template v-else>
					<h4>暂无数据</h4>
				</template>
				
			</template>
			
			<!-- 如果我们点击了更多中的批量选择 如下的选项 -->
			<template v-if="changenumber">
				<div class="custom_item_listzong">
					<van-tabs v-model='tabactive'>
						<van-tab title='默认排序'>
							<div class="follow_items">
								<van-checkbox-group v-model='selectarr' >
									<div class="follow_item" v-for="item in follows ">
										<van-row>
											<van-col span='2'>
												<van-checkbox  class='checked_xuan' checked-color='#fec949'  :name='item.id'></van-checkbox>
											</van-col>
											<van-col span='5'>
												<img :src='item.photo' class="photo"/>
											</van-col>
											<van-col span='12'>
												<div class="follow_center">
													<p class="follow_name">{{item.name}}</p>
													<p class="follow_ke van-ellipsis">18158873627</p>
													<!-- <p class="follow_overdue">过期时间：{{item.overdue}}</p> -->
												</div>
											</van-col>
											<van-col span='5'>
												<p class="formal">正式会员</p>
												<p class="qian">李文</p>
											</van-col>
										</van-row>
									</div>
								</van-checkbox-group>
							</div>
						</van-tab>
						<van-tab>
							<div slot='title'>
								按分配排序<van-icon name='descending' class='custom_icon'></van-icon>
								
							</div>
							<div class="follow_items">
								<van-checkbox-group v-model='selectarr' >
									<div class="follow_item" v-for="item in follows ">
										<van-row>
											<van-col span='2'>
												<van-checkbox  class='checked_xuan' checked-color='#fec949' :name='item.id'></van-checkbox>
											</van-col>
											<van-col span='5'>
												<img :src='item.photo' class="photo"/>
											</van-col>
											<van-col span='12'>
												<div class="follow_center">
													<p class="follow_name">{{item.name}}</p>
													<p class="follow_ke van-ellipsis">13756487965</p>
													<!-- <p class="follow_overdue">过期时间：{{item.overdue}}</p> -->
												</div>
											</van-col>
											<van-col span='5'>
												<p class="formal">正式会员</p>
												<p class="qian">李文</p>
											</van-col>
										</van-row>
									</div>
								</van-checkbox-group>
							</div>
						</van-tab>
						<van-tab >
							<div slot='title' style="text-align: right;"  @click='choose()'>
								筛选<van-icon name='filter-o' class='custom_icon'></van-icon>
							</div>
						</van-tab>
						
					</van-tabs>
				</div>
				<template v-if="chengeorgiveup">
					<div class="static_height"></div>
					<div class="footer">
						<van-row gutter="20">
							<van-col span='8'>
								<van-button type='default' size='large' class='footer_reset' @click='allselect'>全选</van-button>
							</van-col>
							<van-col span='16'>
								<van-button type='default' size='large' class='footer_sure' @click='morechange'>批量更换跟进教练</van-button>
							</van-col>
							
						</van-row>
					</div>
				</template>
				<template v-else>
					<div class="static_height"></div>
					<div class="footer">
						<van-row gutter="20">
							<van-col span='8'>
								<van-button type='default' size='large' class='footer_reset' @click='allselect'>全选</van-button>
							</van-col>
							<van-col span='16'>
								<van-button type='default' size='large' class='footer_sure' @click='giveups'>批量放弃</van-button>
							</van-col>
							
						</van-row>
					</div>
				</template>
				
				
			</template>
			
		</div>
		
		
		
		<!-- 更多的弹窗  -->
		<van-popup position='bottom' v-model='more'>
			<div class="moreselect">
				<div class="addcustom" @click="changecounselor">批量更换跟进教练</div>
				<div class="addcustom" @click="giveup">批量放弃资源</div>
				<div class="addcustom" @click='closepopup'>取消</div>
				
			</div>
		</van-popup>
		
		<!-- 批量更换的的弹窗  -->
		<van-popup position='bottom' v-model='morecahnge'>
			<div class="changeselect">
				<h4>选择新的会籍顾问</h4>
				<van-row>
					<van-col span='12'>
						<div class="teacher" @click='changeteacher'>
							<div class="teacher_left">
								<img src="../../../static/img/jiaolian.png" class="teacher_img">
							</div>
							<div class="teacher_right">
								<p class="teacher_name">员工姓名</p>
								<p class="teacher_id">CA00001</p>
							</div>
							
						</div>
					</van-col>
					<van-col span='12'>
						<div class="teacher"  @click='changeteacher'>
							<div class="teacher_left">
								<img src="../../../static/img/jiaolian.png" class="teacher_img">
							</div>
							<div class="teacher_right">
								<p class="teacher_name">员工姓名</p>
								<p class="teacher_id">CA00001</p>
							</div>
							
						</div>
					</van-col>
					<van-col span='12'>
						<div class="teacher"  @click='changeteacher'>
							<div class="teacher_left">
								<img src="../../../static/img/jiaolian.png" class="teacher_img">
							</div>
							<div class="teacher_right">
								<p class="teacher_name">员工姓名</p>
								<p class="teacher_id">CA00001</p>
							</div>
							
						</div>
					</van-col>
					<van-col span='12'>
						<div class="teacher"  @click='changeteacher'>
							<div class="teacher_left">
								<img src="../../../static/img/jiaolian.png" class="teacher_img">
							</div>
							<div class="teacher_right">
								<p class="teacher_name">员工姓名</p>
								<p class="teacher_id">CA00001</p>
							</div>
							
						</div>
					</van-col>
					<van-col span='12'>
						<div class="teacher">
							<div class="teacher_left">
								<img src="../../../static/img/jiaolian.png" class="teacher_img">
							</div>
							<div class="teacher_right">
								<p class="teacher_name">员工姓名</p>
								<p class="teacher_id">CA00001</p>
							</div>
							
						</div>
					</van-col>
					<van-col span='12'>
						<div class="teacher">
							<div class="teacher_left">
								<img src="../../../static/img/jiaolian.png" class="teacher_img">
							</div>
							<div class="teacher_right">
								<p class="teacher_name">员工姓名</p>
								<p class="teacher_id">CA00001</p>
							</div>
							
						</div>
					</van-col>
					<van-col span='12'>
						<div class="teacher">
							<div class="teacher_left">
								<img src="../../../static/img/jiaolian.png" class="teacher_img">
							</div>
							<div class="teacher_right">
								<p class="teacher_name">员工姓名</p>
								<p class="teacher_id">CA00001</p>
							</div>
							
						</div>
					</van-col>
					<van-col span='12'>
						<div class="teacher">
							<div class="teacher_left">
								<img src="../../../static/img/jiaolian.png" class="teacher_img">
							</div>
							<div class="teacher_right">
								<p class="teacher_name">员工姓名</p>
								<p class="teacher_id">CA00001</p>
							</div>
							
						</div>
					</van-col>
				</van-row>
				
			</div>
		</van-popup>
		
		
		
	</div>
</template>

<script>
	
	export default {
		name:'tcustomsources',
		
		data(){
			return {
				tabactive:0,
				search:'',
				customisok:true,        //数据如果不存咋我们进行数据的判断
				changenumber:false,    //选择我们的更换选项我们开关
				follows:[],				//存放我们的数据
				more:false,				//更多的开关
				selectarr:[],           //去选择的时候我们的数据
				all:true,           	//我们判断点击切换的操作
				morecahnge:false,       //更多切换的弹窗
				selectadds:'正大店',
				arraddress:['正大店','正大店1','正大店2'],
				chengeorgiveup:true,
			}
		},
		
		methods:{
			// 头部的地址的选择
			changeaddress(val){
				console.log(this.selectadds)
				// 根据不同的选择我们调用不同的接口
			},
			back(){
				this.$router.go(-1)
			},
			// 打开我们的底部更多的操作
			onmore(){
				// this.$toast('more')
				this.more = true;
			},
			// 点击进入我们的搜索页面
			onsearch(){
				this.$router.push('/work/tsearch')
				
			},
			choose(){
				console.log(1)
				// 跳转到筛选的页面
				this.$router.push('/work/tsourceschoose')
			},
			// 进入我们的客户详情页
			entercustom(id){
				console.log(id)
				this.$router.push('/work/tcustomdetail/'+id)
			},
			// 底部弹窗放弃的客户的按钮操作
			giveup(){
				this.all = false
				this.more = false;
				this.changenumber = true;
				this.chengeorgiveup = false
				this.selectarr = []
			},
			giveups(){
				// 进行交互
				console.log(this.selectarr)
			},
			// 批量更换我们的按钮的会籍顾问
			changecounselor(){
				this.more = false;
				this.all=false;
				this.changenumber = true;
				this.chengeorgiveup = true
				this.selectarr = []
			},
			// 关闭我们的弹出层
			closepopup(){
				this.more=false;
			},
			// 全选的操作
			allselect(){
				for(let i =0 ; i<this.follows.length;i++){
					// console.log(this.follows.id)
					if(this.selectarr.indexOf(this.follows[i].id) == -1){
						this.selectarr.push(this.follows[i].id)
					}
				}
				console.log(this.selectarr)
				
			},
			// 批量更换的操作
			morechange(){
				console.log(this.selectarr)
				this.morecahnge = true;
				
			},
			changeteacher(){
				// 进行数据操作
				// 1把我们的选中的数据提交后台
				
				// 2把我们处理后的数据加载进来
				
				// 以下是页面的操作
				this.changenumber=false;   //我们的带复选框的那个div 隐藏
				this.customisok=true;		//让我们的客户显示
				this.all = true;           //让我们的客户全部原始的数据打开
				this.morecahnge=false;   //让批量的弹窗关闭
				this.chengeorgiveup = true
				this.selectarr = []
			}
			
		},
		mounted(){
			// this.selectadds = this.arraddress[0]
			// 获取我们要加载的数据
			this.$axios('/api/work/follow').then((res)=>{
				console.log(res)
				this.follows = res.data.follow
			}).catch((err)=>{
				this.$toast('请求出错')
			})
			this.$axios('/api/work/follow').then((res)=>{
				console.log(res)
				this.follows = res.data.follow
			}).catch((err)=>{
				this.$toast('请求出错')
			})
			// 获取我们从筛选过来的数据、
			var storechoose = this.$store.state.choose;
			if(storechoose.length==0 || storechoose.length == undefined){
				// console.log(storechoose)
			}else{
				// 请求我们的数据
				console.log(storechoose)

			}
		},
	}
</script>

<style lang="less" scoped="scoped">
	.custom_icon{
		font-size: 20px;
		margin-top: 10px;;
		vertical-align: -5px;
	}
	.follow_items{
		.checked_xuan{
			text-align: right;
			line-height: 60px;
		}
		.follow_item{
			height: 60px;
			border-bottom: 1px solid #efefef;
			padding:10px 0px;
			background:#fff;
			.photo{
				display: block;
				width: 52px;
				margin: 5px auto;
				border-radius: 100%;
			}
		}
		.follow_center{
			.follow_name{
				font-weight: bold;
				font-size: 16px;
				margin-top: 9px;
			}
			.follow_ke{
				font-size: 12px;
				color: #aaa;
			}
			.follow_overdue{
				font-size: 12px;
				color: #999;
			}
			
			p{
				line-height: 24px;
			}
		}
		.formal{
			margin-top: 3px;
		}
		.formal,.qian{
			font-size: 12px;
			color: #666;
			line-height: 28px;
			text-align: right;
			padding-right: 10px;;
		}
		
	}

	.moreselect{
		background: #fff;
		.addcustom{
			height: 48px;
			line-height: 48px;
			text-align: center;
			border-bottom: 1px solid #efefef;
		}
	}
	.changeselect{
		h4{
			text-align: center;
			line-height: 40px;
		}
		.teacher{
			border-right: 1px solid #efefef;
			border-top: 1px solid #efefef;
			height: 61px;
			.teacher_left{
				display: inline-block;
				width: 30%;
				
				img {
					width: 45px;
					height: 45px;
					border-radius: 50%;
					margin: 8px;
				}
			}
			.teacher_right{
				display: inline-block;
				vertical-align: top;
				padding-top: 8px;
				margin-left: 3%;
				width: 62%;
				p{
					line-height: 25px;
				}
			}
		}
	}
	.footer{
		position: fixed;
		bottom: 5px;
		width: 100%;
		padding: 10px;
		box-sizing: border-box;
		font-size: 16px;
		height: 70px;
		.footer_sure{
			background: linear-gradient(314deg,rgba(255,148,92,1) 0%,rgba(255,194,0,1) 100%);
			color: #fff;
			font-size: 16px;
		}
	}
	.home_title{
		border: 0px;
		outline: none;
		option{
			line-height: 25px;
			
		}
	}
</style>
