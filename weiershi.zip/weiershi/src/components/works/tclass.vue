<template>
	<div class="tclass">
		<!-- 头部引用开始 -->
		<div class="home_header">
			<van-nav-bar class='home_nav'  fixed  @click-left='back()' @click-right='onmore()'>
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<div slot='title'>
					<select class="home_title" v-model="selectadds" @change="changeaddress()">
						
						<option :value="item" v-for=" item in arraddress">{{item}}</option>
						<!-- <option value="2">正大店1</option> -->
						<!-- <option value="3">正大店2</option> -->
					</select>
				</div>
				<!-- <van-icon class='right_icon' name='ellipsis' slot='right'></van-icon> -->
			</van-nav-bar>
		</div>
		<div class="bgcolor"></div>
		<!-- 头部引用结束 -->
		<div class="tclass_item">
			<van-tabs>
				<van-tab title='未消课'>
					
					<div class="follow_items">
						<div class="follow_item" v-for="item in 6 " @click="enterdetail(item)">
							<van-row>
								<van-col span='5'>
									<img src='/static/img/touxiang.png' class="photo"/>
								</van-col>
								<van-col span='11'>
									<div class="follow_center">
										<p class="follow_name">魔鬼增肌体验课</p>
										<p class="follow_ke van-ellipsis">魔鬼增肌1v1</p>
										<p class="follow_overdue">教练姓名 </p>
									</div>
								</van-col>
								<van-col span='8'>
									<p class="formal">2018-11-07 11:45</p>
									<p class="qian">团操课</p>
								</van-col>
							</van-row>
							
						</div>
						
					</div>
					
				</van-tab>
				<van-tab title='已消课'>
					<div class="follow_items">
						<div class="follow_item" v-for="item in 6 ">
							<van-row>
								<van-col span='5'>
									<img src='/static/img/touxiang.png' class="photo"/>
								</van-col>
								<van-col span='11'>
									<div class="follow_center">
										<p class="follow_name">魔鬼增肌体验课</p>
										<p class="follow_ke van-ellipsis">魔鬼增肌1v1</p>
										<p class="follow_overdue">教练姓名 </p>
									</div>
								</van-col>
								<van-col span='8'>
									<p class="formal">2018-11-07 11:45</p>
									<p class="qian">团操课</p>
								</van-col>
							</van-row>
							
						</div>
						
					</div>
				</van-tab>
				<van-tab title='已取消'>
					<div class="follow_items">
						<div class="follow_item" v-for="item in 6 ">
							<van-row>
								<van-col span='5'>
									<img src='/static/img/touxiang.png' class="photo"/>
								</van-col>
								<van-col span='11'>
									<div class="follow_center">
										<p class="follow_name">魔鬼增肌体验课</p>
										<p class="follow_ke van-ellipsis">魔鬼增肌1v1</p>
										<p class="follow_overdue">教练姓名 </p>
									</div>
								</van-col>
								<van-col span='8'>
									<p class="formal">2018-11-07 11:45</p>
									<p class="qian">团操课</p>
								</van-col>
							</van-row>
							
						</div>
						
					</div>
				</van-tab>
			</van-tabs>
		</div>
		
		
		
	</div>
</template>

<script>
	
	export default {
		name:'tclass',
		
		data(){
			return {
				tabactive:0,
				search:'',
				customisok:true,        //数据如果不存咋我们进行数据的判断
				changenumber:false,    //选择我们的更换选项我们开关
				follows:[],				//存放我们的数据
				more:false,				//更多的开关
				selectarr:[],           //去选择的时候我们的数据
				all:true,           	//我们判断点击切换的操作
				morecahnge:false,       //更多切换的弹窗
				selectadds:'正大店',
				arraddress:['正大店','正大店1','正大店2'],
				chengeorgiveup:true,
			}
		},
		
		methods:{
			// 头部的地址的选择
			changeaddress(val){
				console.log(this.selectadds)
				// 根据不同的选择我们调用不同的接口
			},
			back(){
				this.$router.go(-1)
			},
			
			enterdetail(id){
				// this.$router.push('/work/tyuedetail/'+id)
				this.$router.push('/work/tyuedetailteam/'+id)
			}
			
		},
		mounted(){
			
		},
	}
</script>

<style lang="less" scoped="scoped">
	.home_title{
		border: 0px;
		outline: none;
		option{
			line-height: 25px;
			
		}
	}
	.follow_items{
		.follow_item{
			height: 80px;
			border-bottom: 1px solid #ddd;
			padding:10px 0px;
			background:#fff;
			.photo{
				width: 52px;
				margin: 10px;
				border-radius: 100%;
			}
		}
		.follow_center{
			.follow_name{
				font-weight: bold;
				font-size: 16px;
				color: #303034;
			}
			.follow_ke{
				font-size: 14px;
				color:#5E5F64;
			}
			.birth{
				color: #EBB71A;
				font-size: 14px;
				.birth_icon{
					margin-left: 5px;
					font-size: 16px;
					vertical-align: -2px;
				}
			}
			.follow_overdue{
				font-size: 12px;
				color: #898A92;
			}
			
			p{
				line-height: 28px;
			}
		}
		.formal,.qian{
			font-size: 12px;
			color: #898A92;
			line-height: 28px;
			text-align: right;
			padding-right: 10px;;
		}
		
	}
</style>
