<template>
	<div class="tsearch">
		<!-- 头部引用开始 -->
		<!-- <div class="home_header">
			<van-nav-bar class='home_nav' title='我的客户' fixed  @click-left='back()' @click-right='more()'>
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<van-icon class='right_icon' name='bell' slot='right'></van-icon>
			</van-nav-bar>
		</div> -->
		<!-- <div class="bgcolor"></div> -->
		<!-- 头部引用结束 -->

		<div class="custom_item">

			<div class="custom_search">
				<van-search placeholder='请输入关键词' v-model='search' show-action @search='onsearch()' @cancel='oncancel()'>
					<<!-- div slot='action' @click='onsearch()'>
			</div> -->
			</van-search>
		</div>

		<!-- 这层div 判断我们是否已经搜索数据了 -->
		<template v-if="searchresult">
			<!-- 数据模板 -->
			<div class="follow_items">
				<h4 class="search_title">搜索发现</h4>
				<div class="follow_item" v-for="item in follows " @click="entercustom(item.id)">
					<van-row>
						<van-col span='5'>
							<img :src='item.photo' class="photo"/>
						</van-col>
						<van-col span='14'>
							<div class="follow_center">
								<p class="follow_name">{{item.name}}</p>
								<p class="follow_ke van-ellipsis">18158873627</p>
							</div>
						</van-col>
						<van-col span='5'>
							<p class="formal">正式会员</p>
							<p class="qian">李文</p>
						</van-col>
					</van-row>
				</div>
			</div>
		</template>
		<!-- 如果没搜索我们出现最近搜索 -->
		<template v-else>
			<template v-if="searchnoresult">
				<div class="searchnoresult">
					<h4>没有搜索到相关信息</h4>
				</div>
			</template>
			
			<!-- 点击关闭的按钮去清除记录 -->
			<template v-if="show">
				
				<div class="lastsearch">
					<h4>最近搜索 <van-icon name='cross' class='pull-right' @click='closelastsearch()'></van-icon>
					</h4>
					<!-- 判断我们的有没有搜索记录 -->
					<template v-if="lastsearch">
						<div class="search_record">
							<span class="search_record_item" @click="search_btn('张三')">张三</span>
							<span class="search_record_item" @click="search_btn('李四')">李四</span>
							<span class="search_record_item" @click="search_btn('王二')">王二</span>
						</div>
					</template>
					<template v-else>
						<p class="search_wu">暂无搜索记录</p>
					</template>

				</div>
			</template>
			
		</template>
	</div>



	</div>
</template>

<script>
	export default {
		name: 'tsearch',

		data() {
			return {
				search: '',     //我们搜索栏绑定的数据
				searchresult:false,  //判断我们的有没有搜索结果 默认false
				searchnoresult:false,   //没有搜索到的结果的错误处理
				show: true,     //是否显示我们的最近搜索 默认false
				lastsearch: false,   //判断是否有我们的搜索记录 默认 false 
				follows:[],      //我们的数据放在follows中
			}
		},
		methods: {
			// 取消选择的时候我们应该返回上一级
			oncancel() {
				this.$router.go(-1)
			},
			search_btn(value){
				this.search = value
				// 调用接口 查询数据
				console.log(value)
				
			},
			// 点击x的的关闭按钮
			closelastsearch(){
				this.show =false;
			},
			entercustom(id){
				this.$router.push('/work/tcustomdetail/'+id)
			},
			onsearch() {
				console.log(this.search)
				// this.$router.push('/work/search')
				if (this.search != '') {
					this.$toast('搜索中')
					let searchval = this.search
					this.$axios({
						method: 'get',
						url: '/api/work/customs',
						params: {
							value: searchval
						}
					}).then((res) => {
						console.log(res)
						this.follows = res.data.follow
						if (res.data.follow != '') {
							this.show = false;
							this.searchresult = true;
							this.follows = res.data.follow
						} else {
							this.show = false;
							this.searchresult = false;
							this.searchnoresult = true
						}


					}).catch((err) => {
						this.$toast('请求出错')
					})
				} else {
					this.$toast('请输入关键字')
				}
			}
		},
		mounted() {
			// 获取我们要加载的数据
			this.$axios('/api/work/follow').then((res)=>{
				console.log(res)
				this.follows = res.data.follow
			}).catch((err)=>{
				this.$toast('请求出错')
			})
		},
	}
</script>

<style lang="less" scoped="scoped">
	.lastsearch {
		padding:10px;
		padding-bottom: 20px;
		border-bottom: 1px solid #efefef;
		h4 {
			font-size: 14px;
			font-family: PingFangSC-Regular;
			font-weight: 400;
			color: rgba(48, 48, 52, 1);
			line-height: 30px;
			margin-bottom: 10px;
			i{
				margin-top: 8px;
				font-size: 16px;
			}
		}

		.search_wu {
			font-size: 12px;
			color: #BEBEC8;
		}
		.search_record{
			margin-top: 15px;
			.search_record_item{
				padding: 6px 12px;
				border: 1px solid #E9E9E9;
				margin-right: 5px;;
			}
		}
		
	}
	.follow_items{
		.search_title{
			color: #303034;
			font-size: 14px;
			line-height: 50px;
			padding-left: 10px;
			border-bottom:1px solid #efefef ;
		}
		.follow_item{
			height: 60px;
			border-bottom: 1px solid #ddd;
			padding:10px 0px;
			background:#fff;
			.photo{
				display: block;
				width: 52px;
				margin: 5px auto;
				border-radius: 100%;
			}
		}
		.follow_center{
			.follow_name{
				font-weight: bold;
				font-size: 16px;
				margin-top: 9px;
				color: #FBC648;
			}
			.follow_ke{
				font-size: 12px;
				color: #aaa;
			}
			.follow_overdue{
				font-size: 12px;
				color: #999;
			}
			
			p{
				line-height: 24px;
			}
		}
		.formal{
			margin-top: 3px;
		}
		.formal,.qian{
			font-size: 12px;
			color: #666;
			line-height: 28px;
			text-align: right;
			padding-right: 10px;;
		}
		
	}
</style>
