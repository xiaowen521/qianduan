<template>
	<div class="invitation">
		<!-- 头部引用开始 -->
		<div class="home_header">
			<van-nav-bar class='home_nav' title='邀约详情' fixed  @click-left='back()' @click-right='edit()'>
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<van-icon class='right_icon' slot='right'>修改</van-icon>
			</van-nav-bar>
		</div>
		<div class="bgcolor"></div>
		<!-- 头部引用结束 -->
		
		<div class="invitation_item">
			
			<div class="detail">
				<van-cell-group>
					<van-field label='邀约人' :disabled='editisok' v-model='name' input-align='right'></van-field>
					<van-field label='邀约类型' :disabled='editisok' v-model='type' input-align='right'></van-field>
					<van-field label='邀约时间' :disabled='editisok' v-model='time' input-align='right'></van-field>
					<van-field label='到访门店' :disabled='editisok' v-model='address' input-align='right'></van-field>
				</van-cell-group>
			</div>
			
			<div class="detail detail_padding">
				<van-cell-group>
				   <van-cell title="邀约备注" :disabled='editisok' label="这是备注信息这是备注信息这是备注信息这是备注信息 是备注信息" />
				</van-cell-group>
				<h4></h4>
			</div>
			<van-button class='stop btns_color' size='large' @click='stop()'>停用</van-button>
		</div>
			
	
		
		
		
	</div>
</template>

<script>
	
	export default {
		name:'invitation',
		
		data(){
			return {
				name:'客户姓名',
				type:'到店体验',
				time:'2018-12-25',
				address:'环球金融会所',
				note:'',
				editisok:true,
				
			}
		},
		methods:{
			back(){
				this.$router.go(-1)
			},
			// 打开我们的底部更多的操作
			edit(){
				// this.$toast('more')
				this.editisok = false
			},
			stop(){
				// 发送
			}
			
			
		},
		mounted(){
			
		},
	}
</script>

<style lang="less" scoped="scoped">
	.right_icon{
		font-size: 14px;
	}
	.detail{
		margin-top: 16px;
	}
	.stop{
		position: fixed;
		width: 90%;
		height: 50px;
		bottom: 10px;
		box-sizing: border-box;
		left: 5%;
		color: #fff;
		font-size: 16px;
	}
	.detail_padding{
		padding: 10px 0px;
		background: #fff;
	}
</style>
