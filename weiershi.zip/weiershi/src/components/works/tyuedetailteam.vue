<template>
	<div class="tyuedetailteam">
		<!-- 头部引用开始 -->
		<div class="home_header">
			<van-nav-bar class='home_nav' title='预约私教课' fixed  @click-left='back()' @click-right='onmore()'>
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<!-- <van-icon class='right_icon' name='ellipsis' slot='right'></van-icon> -->
			</van-nav-bar>
		</div>
		<div class="bgcolor"></div>
		<!-- 头部引用结束 -->
		
		<div class="tyuedetail_header">
			<div class="tyuedetail_header_img">
				<img src="http://s7.sinaimg.cn/mw690/003xtv7Egy6Uaifqje616&690">
			</div>
			<div class="header_title">
				<p><img src="/static/img/free.png"></p>
				<h4>40人首次魔鬼训练1v1</h4>
			</div>
			
		</div>
		
		<div class="tyuedetail_content">
			
			
			<div class="tyuedetail_detail">
				<van-cell class='margin_top' title='上课时间' value='2018-11-22 13:00'></van-cell>
				<van-cell title='上课门店' value='环球金融会所'></van-cell>
				<van-cell title='预约人数' value='1/40'></van-cell>
				
			</div>
			
		</div>
		
		
		
	</div>
</template>

<script>
	
	export default {
		name:'tyuedetailteam',
		
		data(){
			return {
				
			}
		},
		methods:{
			back(){
				this.$router.go(-1)
			},
			
			
			
		},
		mounted(){
			
		},
	}
</script>

<style lang="less" scoped="scoped">
	.tyue_xuanze{
		padding: 0px 15px;
		.xuanze_item{
			padding: 10px 0px;
			border-bottom: 1px solid #f2f2f2;
			.tyue_right{
				h4{
					font-size: 16px;
					color: #303034;
					line-height: 30px;
					span{
						float: right;
					}
				}
				p{
					font-size: 12px;
					color: #898A92;
					line-height: 30px;
					span{
						float: right;
					}
				}
				
			}
			.xuan_radio{
				line-height: 40px;
			}
		}
	}
	.tyuedetail_header{
		position: relative;
		.tyuedetail_header_img{
			position: relative;
			height: 185px;
			img{
				width: 100%;
				height: 185px;
			}
		}
		.header_title{
			position: absolute;
			bottom: 0px;
			width: 100%;
			height: 70px;
			z-index: 10;
			padding:8px 15px;
			box-sizing: border-box;
			background:linear-gradient(360deg,rgba(0,0,0,1) 0%,rgba(0,0,0,0) 100%);
			opacity: 0.8;
			h4{
				line-height: 40px;
				color: #fff;
				font-size: 16px;
			}
		}
	}
	.tyuedetail_content{
		
		.tyuedetail_people{
			padding: 10px;
			background: #fff;
			img{
				width: 52px;
				height: 52px;
				margin: 5px;
			}
			h4{
				font-size: 16px;
				color: #303034;
				line-height: 40px;
				padding-left: 5px;
				span{
					font-size: 12px;
					color:#898A92;
				}
			}
			p{
				padding-left: 5px;
				font-size: 12px;
				color: #898A92;
			}
		}
		.notes{
			background: #fff;
			font-size: 14px;
			padding: 5px 10px;
			color: #323233;
			textarea{
				color: #898A92;
			}
		}
		.margin_top{
			margin-top: 15px;
		}
	}
</style>
