<template>
	<div class="tentry">
		<!-- 头部引用开始 -->
		<div class="home_header">
			<van-nav-bar class='home_nav' title='录入体侧数据' fixed  @click-left='back()' @click-right='onmore()'>
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<!-- <van-icon class='right_icon' name='ellipsis' slot='right'></van-icon> -->
			</van-nav-bar>
		</div>
		<!-- <div class="bgcolor"></div> -->
		<!-- 头部引用结束 -->
		
		<div class="tentry_item">
			<div class="entry_item_header">
				<p>第3步 <span><b>3</b>/3</span></p>
			</div>
			
			<div class="entry_item">
				<van-field class='items' label='脂肪控制(公斤)' placeholder='请输入' input-align='right'></van-field>
				<van-field class='items' label='左上肢肌肉(公斤)' placeholder='请输入' input-align='right'></van-field>
				<van-field class='items' label='右上肢肌肉(公斤)' placeholder='请输入' input-align='right'></van-field>
				<van-field class='items' label='左下肢肌肉(公斤)' placeholder='请输入' input-align='right'></van-field>
				<van-field class='items' label='右下肢肌肉(公斤)' placeholder='请输入' input-align='right'></van-field>
				<van-field class='items' label='躯干肌肉(公斤)' placeholder='请输入' input-align='right'></van-field>
				
				<van-button type='default' size='large' class='next_btn' @click='sure()'>提交</van-button>
			</div>
			
			
			
			
		</div>
		
		
		
	</div>
</template>

<script>
	
	export default {
		name:'tentry3',
		
		data(){
			return {
				tabactive:0,
				search:'',
				customisok:true,        //数据如果不存咋我们进行数据的判断
				changenumber:false,    //选择我们的更换选项我们开关
				follows:[],				//存放我们的数据
				more:false,				//更多的开关
				selectarr:[],           //去选择的时候我们的数据
				all:true,           	//我们判断点击切换的操作
				morecahnge:false,       //更多切换的弹窗
			}
		},
		methods:{
			back(){
				this.$router.go(-1)
			},
			// 打开我们的底部更多的操作
			onmore(){
				// this.$toast('more')
				this.more = true;
			},
			sure(){
				var id = 3;
				this.$router.replace('/work/tcustomdetail/'+id)
			}
			
		},
		mounted(){
			
		},
	}
</script>

<style lang="less" scoped="scoped">
	.tentry_item{
		padding: 0px 24px 15px;
		background: #FED249;
		position: absolute;
		width: 100%;
		height: calc(100% - 50px);
		top: 50px;
		left: 0px;
		box-sizing: border-box;
		.entry_item_header{
			color: #B37F2A;
			p{
				line-height: 50px;
				font-size: 16px;
				span{
					float: right;
					font-size: 12px;
					b{
						 font-size: 24px;
						 font-weight: normal;
					}
				}
			}
		}
		.entry_item{
			background: #fff;
			padding-bottom: 10px;
			position: absolute;
			width: 90%;
			left: 5%;
			height: calc(100% - 70px);
			box-sizing: border-box;
			.items{
				height: 55px;
				line-height: 40px;
				border-bottom: 1px solid #efefef;
			}
			.next_btn{
				position: fixed;
				bottom: 30px;
				display: block;
				width: 84%;
				left: 8%;
				box-shadow:0px 2px 16px 0px rgba(0,0,0,0.1);
			}
		}
	}
</style>
