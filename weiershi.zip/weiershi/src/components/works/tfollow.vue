<template>
	<div class="tfollow">
		<!-- 头部引用开始 -->
		<div class="home_header">
			<van-nav-bar class='home_nav' title='t跟进管理' fixed  @click-left='back()'>
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<!-- <van-icon class='right_icon' name='bell' slot='right'></van-icon> -->
			</van-nav-bar>
		</div>
		<div class="bgcolor"></div>
		<!-- 头部引用结束 -->
		
		
		<div class="follow_tabs">
			<van-tabs v-model='tabactive' class='haha'>
				<van-tab title='未成交' class='lala'>
					
					<div class="follow_items">
						<div class="follow_item" v-for="item in follows " @click="entercustom(item.id)">
							<van-row>
								<van-col span='5'>
									<img :src='item.photo' class="photo"/>
								</van-col>
								<van-col span='14'>
									<div class="follow_center">
										<p class="follow_name">{{item.name}}</p>
										<p class="follow_ke van-ellipsis">分配时间：{{item.fentime}}</p>
										<p class="follow_overdue">过期时间：{{item.overdue}}</p>
									</div>
								</van-col>
								<van-col span='5'>
									<p class="formal">{{item.nomal}}</p>
									<p class="qian">{{item.times}}</p>
								</van-col>
							</van-row>
						</div>
						<!-- 模板样式 -->
						<!-- <div class="follow_item">
							<van-row>
								<van-col span='5'>
									<img src="../../assets/img/a1.png" class="photo"/>
								</van-col>
								<van-col span='14'>
									<div class="follow_center">
										<p class="follow_name">蒋芳</p>
										<p class="follow_ke">《魔鬼腹肌》 -- 10课时</p>
										<p class="follow_overdue">过期时间：2019-08-02</p>
									</div>
								</van-col>
								<van-col span='5'>
									<p class="formal">正式会员</p>
								</van-col>
							</van-row>
						</div> -->
					</div>
					
				</van-tab>
				<van-tab title='近期生日'>
					<div class="follow_items">
						<div class="follow_item" v-for="item in follows_you ">
							<van-row>
								<van-col span='5'>
									<img :src='item.photo' class="photo"/>
								</van-col>
								<van-col span='14'>
									<div class="follow_center">
										<p class="follow_name">{{item.name}}</p>
										<p class="follow_ke van-ellipsis"><span class="birth">今日生日<van-icon class='birth_icon' name='birthday-cake-o'></van-icon></span></p>
										<p class="follow_overdue">联系时间：2018-08-02 </p>
									</div>
								</van-col>
								<van-col span='5'>
									<p class="formal">{{item.nomal}}</p>
									<p class="qian">{{item.times}}</p>
								</van-col>
							</van-row>
							
						</div>
						
					</div>
				</van-tab>
				<van-tab title='近期过期'>
					<div class="follow_items">
						<div class="follow_item" v-for="item in follows_overdue ">
							<van-row>
								<van-col span='5'>
									<img :src='item.photo' class="photo"/>
								</van-col>
								<van-col span='14'>
									<div class="follow_center">
										<p class="follow_name">{{item.name}}</p>
										<p class="follow_ke van-ellipsis">过期时间：2018-08-02</p>
										<p class="follow_overdue">联系时间：2018-08-02</p>
									</div>
								</van-col>
								<van-col span='5'>
									<p class="formal">{{item.nomal}}</p>
								</van-col>
							</van-row>
						</div>
						
					</div>
				</van-tab>
				<van-tab title='长期未约课'>
					<div class="follow_items">
						<div class="follow_item" v-for="item in follows_wei ">
							<van-row>
								<van-col span='5'>
									<img :src='item.photo' class="photo"/>
								</van-col>
								<van-col span='14'>
									<div class="follow_center">
										<p class="follow_name">{{item.name}}</p>
										<p class="follow_ke van-ellipsis">最近进店：2018-08-02 </p>
										<p class="follow_overdue">联系时间：2018-08-02</p>
									</div>
								</van-col>
								<van-col span='5'>
									<p class="formal">{{item.nomal}}</p>
									<p class="qian">4天</p>
								</van-col>
							</van-row>
						</div>
						
					</div>
				</van-tab>
			</van-tabs>
		</div>
		
	</div>
</template>

<script>
	
	export default {
		name:'tfollow',
		
		data(){
			return {
				tabactive:0,
				follows:[],
				follows_you:[],
				follows_overdue:[],
				follows_wei:[],
			}
		},
		methods:{
			back(){
				this.$router.go(-1)
			},
			tips(){
				this.$toast('暂无消息')
			},
			kehu(){
				this.$toast('follow')
			},
			entercustom(id){
				this.$router.push('/work/tcustomdetail/'+id)
			}
		},
		mounted(){
			this.$axios('/api/work/follow').then((res)=>{
				console.log(res)
				this.follows = res.data.follow
			}).catch((err)=>{
				this.$toast('请求出错')
			})
			this.$axios('/api/work/follow1').then((res)=>{
				console.log(res)
				this.follows_you = res.data.follow
			}).catch((err)=>{
				this.$toast('请求出错')
			})
			this.$axios('/api/work/follow2').then((res)=>{
				console.log(res)
				this.follows_overdue = res.data.follow
			}).catch((err)=>{
				this.$toast('请求出错')
			})
			this.$axios('/api/work/follow3').then((res)=>{
				console.log(res)
				this.follows_wei = res.data.follow
			}).catch((err)=>{
				this.$toast('请求出错')
			})
		},
	}
</script>

<style lang="less" scoped="scoped">
	.right_icon{
		color: #aaa;
		font-size: 20px;
	}
	//没起作用
	.follow_tabs .van-tabs__wrap{
		box-shadow: 0px 0px 15px #ddd;
	}
	.follow_items{
		.follow_item{
			height: 80px;
			border-bottom: 1px solid #ddd;
			padding:10px 0px;
			background:#fff;
			.photo{
				width: 52px;
				margin: 10px;
				border-radius: 100%;
			}
		}
		.follow_center{
			.follow_name{
				font-weight: bold;
				font-size: 16px;
				color: #303034;
			}
			.follow_ke{
				font-size: 14px;
				color:#5E5F64;
			}
			.birth{
				color: #EBB71A;
				font-size: 14px;
				.birth_icon{
					margin-left: 5px;
					font-size: 16px;
					vertical-align: -2px;
				}
			}
			.follow_overdue{
				font-size: 12px;
				color: #898A92;
			}
			
			p{
				line-height: 28px;
			}
		}
		.formal,.qian{
			font-size: 12px;
			color: #898A92;
			line-height: 28px;
			text-align: right;
			padding-right: 10px;;
		}
		
	}
		
		
	
</style>
