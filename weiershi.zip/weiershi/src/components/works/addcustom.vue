<template>
	<div class="addcustom">
		<!-- 头部引用开始 -->
		<div class="home_header">
			<van-nav-bar class='home_nav' title='添加客户' fixed  @click-left='back()' >
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<van-icon class='right_icon' name='ellipsis' slot='right'></van-icon>
			</van-nav-bar>
		</div>
		<!-- <div class="bgcolor"></div> -->
		<!-- 头部引用结束 -->
		
		<div class="addcustom_item">
			
			<van-cell-group class='add_item_first'>
				<van-field v-model='name' label='姓名' placeholder='请输入姓名' class='addcustom_items' input-align='right'></van-field>
				<van-field v-model='phone' label='手机' placeholder='请输入' class='addcustom_items' input-align='right'></van-field>
				<van-cell title='性别'   class='addcustom_items'>
					
					<div slot='right-icon'>
						<van-button :class='sex[0] == 1 ? "active" : "nomarl" '  @click='changesex(1)' >男</van-button>
						<van-button :class='sex[0] == 2 ? "active" : "nomarl" '  @click='changesex(2)' >女</van-button>
					</div>
					
				</van-cell>
				<van-cell title='信息来源' :value='source_value'  class='addcustom_items' @click='source_xuan()' is-link></van-cell>
			</van-cell-group>
			
			<van-cell-group class='add_item_first'>
				<van-field v-model='idcard' label='身份证号' placeholder='请输入身份证号' class='addcustom_items' input-align='right'></van-field>
				<van-cell title='生日' :value='birth_value'  class='addcustom_items' @click='birth_xuan()' is-link></van-cell>
				<van-cell title='客户分类' :value='sort_value'  class='addcustom_items' @click='sort_xuan()' is-link></van-cell>
				
				<p class="beizhu">备注</p>
				<van-field v-model='note' type="textarea"  placeholder='请输备注信息' autosize class='addcustom_note'></van-field>
			</van-cell-group>
			
		</div>
		
		<div class="static_height"></div>
		<div class="footer">
			<van-row gutter="20">
				<van-col span='8'>
					<van-button type='default' size='large' class='footer_reset' @click='addcreated'>直接创建</van-button>
				</van-col>
				<van-col span='16'>
					<van-button type='default' size='large' class='footer_sure' @click='next'>下一步</van-button>
				</van-col>
				
			</van-row>
		</div>
		
		<!-- //信息来源的的选择 -->
		<van-popup v-model='sour_popup' position='bottom'>
			<van-picker show-toolbar :columns='sourcedata' @confirm='onconfirm' @cancel='oncancel' @change='onchange' ></van-picker>
		</van-popup>
		<!-- //生日的的选择 -->
		<van-popup v-model='birth_popup' position='bottom'>
			<van-picker show-toolbar :columns='birthdata' @confirm='onconfirm1' @cancel='oncancel1' @change='onchange1' ></van-picker>
		</van-popup>
		<!-- //客户分类的的选择 -->
		<van-popup v-model='sort_popup' position='bottom'>
			<van-picker show-toolbar :columns='sortdata' @confirm='onconfirm2' @cancel='oncancel2' @change='onchange2' ></van-picker>
		</van-popup>
		
	</div>
</template>

<script>
	
	export default {
		name:'addcustom',
		
		data(){
			return {
				'name':'',   //绑定姓名
				'phone':'',  //绑定手机号
				'idcard':'',  //身份证
				'note':'',   // 备注
				'sex':[1],    //
				
				'sour_popup':false,   //开启 信息来源的弹窗
				'sourcedata':['微信','qq','shoji'],  //弹窗里面的数据
				'source_value':'请输入',     //弹窗数据放入的到我们的列表中
				
				'birth_popup':false,   //开启 生日的弹窗
				'birthdata':['1993','06','08'],  //弹窗里面的数据
				'birth_value':'请输入',     //弹窗数据放入的到我们的列表中
				
				'sort_popup':false,   //开启 分类来源的弹窗
				'sortdata':['1993','06','08'],  //弹窗里面的数据
				'sort_value':'请输入',     //弹窗数据放入的到我们的列表中
			}
		},
		methods:{
			back(){
				this.$router.go(-1)
			},
			// 信息来源的选择 一下四个是我们的选择操作
			source_xuan(){
				this.sour_popup = true
			},
			onconfirm(value,index){
				this.sour_popup = false;
				this.source_value = value
			},
			onchange(picker,value,index){
				console.log(value)
				this.source_value = value
			},
			oncancel(){
				this.sour_popup = false
			},
			// 信息来源的选择 一下四个是我们的选择操作
			birth_xuan(){
				this.birth_popup = true
			},
			onconfirm1(value,index){
				this.birth_popup = false;
				this.birth_value = value
			},
			onchange1(picker,value,index){
				console.log(value)
				this.birth_value = value
			},
			oncancel1(){
				this.birth_popup = false
			},
			// 信息来源的选择 一下四个是我们的选择操作
			sort_xuan(){
				this.sort_popup = true
			},
			onconfirm2(value,index){
				this.sort_popup = false;
				this.sort_value = value
			},
			onchange2(picker,value,index){
				console.log(value)
				this.sort_value = value
			},
			oncancel2(){
				this.sort_popup = false
			},
			// 选择性别
			changesex(val){
				
				if(this.sex.length == 0){
					this.sex.push(val)
				}else{
					this.sex=[];
					this.sex.push(val)
				}
				
			},
			// 创建的开始
			addcreated(){
				if(this.name == '' || this.name == undefined){
					this.$toast('请输入姓名')
				}else if(this.phone == '' || this.phone == undefined){
					this.$toast('请输入手机号')
				}else if(this.source_value == '请输入' || this.source_value == undefined){
					this.$toast('请输入信息来源')
				}else if(this.idcard == '' || this.idcard == undefined){
					this.$toast('请输入身份证号码')
				}else if(this.birth_value == '请输入' || this.birth_value == undefined){
					this.$toast('请输入生日')
				}else if(this.sort_value == '请输入' || this.sort_value == undefined){
					this.$toast('请输入客户分类')
				}else if(this.note == '' || this.note == undefined){
					this.$toast('请输入备注')
				}else{
					// 把数据传入后台
				}
			},
			// 进入下一页
			next(){
// 				if(this.name == '' || this.name == undefined){
// 					this.$toast('请输入姓名')
// 				}else if(this.phone == '' || this.phone == undefined){
// 					this.$toast('请输入手机号')
// 				}else if(this.source_value == '请输入' || this.source_value == undefined){
// 					this.$toast('请输入信息来源')
// 				}else if(this.idcard == '' || this.idcard == undefined){
// 					this.$toast('请输入身份证号码')
// 				}else if(this.birth_value == '请输入' || this.birth_value == undefined){
// 					this.$toast('请输入生日')
// 				}else if(this.sort_value == '请输入' || this.sort_value == undefined){
// 					this.$toast('请输入客户分类')
// 				}else if(this.note == '' || this.note == undefined){
// 					this.$toast('请输入备注')
// 				}else{
// 					// 把数据传入后台
// 					
// 					// 然后进入更多的选择
// 					
// 				}
				this.$router.push('/work/addcustom2')
			}
		
			
		},
		mounted(){
			
		},
	}
</script>

<style lang="less" scoped="scoped">
	.addcustom_item{
		padding:0px 10px;
		.add_item_first{
			padding-top:10px; 
			.addcustom_items{
				.van-field__control{
					text-align: right;
				}
				
			}
			.addcustom_note{
				height: 110px;
				border: 1px solid #efefef;
				word-break: break-all;
				word-wrap: break-word;
			}
			.beizhu{
				line-height: 40px;
				padding-left: 10px;
			}
			.active{
				background: #FEC949;
				color: #fff;
				border: 0px;
				line-height: 34px;
				height: 34px;
			}
			.nomarl{
				background: #f5f5f5;
				border: 0px;
				line-height: 34px;
				height: 34px;
			}
		}
	}
	.footer{
		position: fixed;
		bottom: 5px;
		width: 100%;
		padding: 10px;
		box-sizing: border-box;
		font-size: 16px;
		height: 70px;
		.footer_sure{
			background: linear-gradient(314deg,rgba(255,148,92,1) 0%,rgba(255,194,0,1) 100%);
			color: #fff;
			font-size: 16px;
		}
	}
</style>
