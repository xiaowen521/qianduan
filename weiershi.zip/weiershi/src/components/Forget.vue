<template>
	<div class="forget">
		<!-- 头部 -->
		<div class="home_header">
			<van-nav-bar class='home_nav' title='重置密码' fixed @click-left='back' @click-right='home'>
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<!-- <van-icon class='right_icon' name='wap-home' slot='right' ></van-icon> -->
			</van-nav-bar>
		</div>
		<!-- 头部结束 -->
		
		<div class="forget_cont">
			
			<van-cell-group>
				
				<van-field placeholder='请输入手机号' v-model='phone' clearable class='login_input'></van-field>
				<van-field placeholder='请输入验证码' v-model='code'  :disabled='yanzheng' class='login_input'>
					<van-button  slot='button' size='small' type='default' class='code_yan' @click='codeyan' >{{ codetext }}</van-button>
				</van-field>
				<van-field placeholder='请输入新密码' v-model='password' clearable :right-icon='righticons' :type='typevalue' class='login_input' @click-right-icon='eyes'> {{checkeyes}}</van-field>
				
			</van-cell-group>
			
			<div class="login_cont_xia">
				<template v-if='loginbtn'>
					<van-button size='large' class='login_signin' disabled >提交{{loginbtns}}</van-button>
				</template>
				<template v-else='loginbtn'>
					<van-button size='large' class='login_signin' @click='tijiao' >提交{{loginbtns}}</van-button>
				</template>
			</div>
		</div>
		
		
		
	</div>
</template>

<script>
	export default {
		name:'Forget',
		data() {
			return {
				phone:'',
				code:'',
				password:'',
				typevalue:'password',  //转换我们的type值
				righticons:'eye-o',    // 转换我们的眼睛图标
				eyesclick:1,           //眼睛的判断条件
				loginbtn:true,			//判断按钮的那个
				codetext:'获取验证码',   //验证码倒计时
				yanzheng:true,
			}
			
		},
		computed:{
			loginbtns:function(){
				if(this.phone == '' || this.code == '' || this.password == ''){
					this.loginbtn = true
				}else{
					this.loginbtn =  false
				}
			},
			// 检查我们的眼睛图标有没有点击 换图标和换type属性值
			checkeyes:function(){
				if(this.eyesclick % 2 == 0){
					this.typevalue = 'text';
					this.righticons = 'eye';
				}else{
					this.typevalue = 'password';
					this.righticons = 'eye-o';
				}
			},
		},
		methods:{
			back(){
				this.$router.go(-1)
			},
			home(){
				this.$router.push('/')
			},
			// 点击的眼睛的判断
			eyes(){
				this.eyesclick++
			},
			// 点击验证码获取的操作
			codeyan(){
				var that = this
				this.yanzheng=false
				if(this.phone == ''){
					this.$toast('请输入手机号');
				}else{
					this.$toast('注意查收短信');
					var times = 60;
					setInterval(function(){
						times--;
						
						if(times<=0){
							that.codetext = '获取验证码'
						}else{
							that.codetext = times
						}
					},1000)
				}
				
			},
			// 提交获取按钮的操作
			tijiao(){
				var that = this
				console.log(this.$store.state.token)
				this.$axios({
					url:'/api/forget'
				}).then((res)=>{
					console.log(res)
					this.$toast.loading({
						loadingType:'spinner',
						message:'正在修改'
					})
					this.$store.commit('changetoken',res.token)
					setTimeout(function(){
						that.$router.push('./')
						that.$toast.success('修改成功')
					},3000)
					
				}).catch((err)=>{
					this.$toast(err.msg)
				})
			},
		}
	}
</script>

<style lang="less" scoped="scoped">
	.home_header{
		height: 50px;
	}
	.home_nav{
		box-shadow: 0px 0px 15px #f0f0f0;
	}
	.home_nav .home-left-nav{
		color: #000000;
		vertical-align: middle;
		font-size: 14px;
		&:before{
			vertical-align: -2px;
		}
	}
	.home_nav .right_icon{
		color: #000;
		font-size: 18px;
	}
	.forget_cont{
		width: 86%;
		margin: 30px auto;
	}
	.login_input {
		// border: 1px solid #ddd;
		margin-bottom: 18px;
		border-radius: 5px;
		background: #f5f5f5;
		i{
			font-size:20px;
		}
	}
	.code_yan{
		background: #f5f5f5;
		border: 0px;
	}
	.login_cont_xia {
		width: 100%;
		margin: 30px auto;
	
		.login_signin {
			border: 0px;
			background: linear-gradient(left, #ffc200, #ff945a);
			color: #fff;
			letter-spacing: 3px;
			padding-left: 3px;
		}
	}
	
</style>