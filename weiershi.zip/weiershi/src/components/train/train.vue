<template>
	<div class="zongti">

		<div class="home_header">
			<van-nav-bar class='home_nav' title='培训' fixed @click-right='home'>
				<!-- <van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon> -->
				<van-icon class='right_icon iconfont' slot='right'><i class="iconfont icon-caidan"></i></van-icon>
			</van-nav-bar>
		</div>
		<div class="train_content">
			<template v-if="shuju1">
				<div class="train_header">
					<div class="train_img">
						<img src="../../assets/img/train.jpg">
					</div>
					<div class="train_header_cont">
						<h4>{{trainimg.title}}</h4>
						<p>{{trainimg.time}} <span class='biao'>{{trainimg.biao}}</span></p>
					</div>
				</div>
			</template>
			<template v-else>
				<p>暂无数据</p>
			</template>
			<div class="train_cont_item">
				<template v-if="shuju">
					<van-cell-group>
						<div class="train_item" v-for="(item,index) in trainlist" :key='item.jiid' @click='train_detail(item.jiid)'>
							<van-row>
								<van-col :span='10' class='img_tu'>
									<img :src='item.img'>
								</van-col>
								<van-col :span='14'>
									<div class="train_item_right">
										<h4>{{item.title}}</h4>
										<p class="time">{{item.time }}</p>
										<p class="jineng"><span>{{item.jineng}}</span></p>
									</div>
								</van-col>
							</van-row>
						</div>

					</van-cell-group>
				</template>
				<template v-else>
					<p> 暂无数据</p>
				</template>
			</div>

			<!-- <div class="static_height">{{sortnums}}</div> -->
		</div>
		<!-- 
		<div  style='display: none;'>
			<sort v-on:changesort='changesorts'></sort>
		</div> -->

		<pfooter :activenum='2'></pfooter>
	</div>
</template>

<script>
	import Pfooter from '@/components/Pfooter'
	import sort from '@/components/train/sort'

	// import '../../../static/js/swiper.js'

	export default {
		name: 'train',
		data() {
			return {
				trainlist: [], //每个项目的类别
				trainimg: '', //头部的加载
				shuju: true,
				shuju1: true,
			}
		},
		components: {
			Pfooter,
			sort,
		},
		computed: {

			// 计算我们的sort 返回值 筛选文章

			sortnums() {
				var that = this
				setTimeout(function() {
					// console.log(that.$store.state.sort)
					let sortid = that.$store.state.sort;
					switch (sortid) {
						case 1:
							that.$axios('/api/train/sort1').then((res) => {
								// console.log(res.data)
								that.trainlist = res.data.tranlist
							}).catch((err) => {
								that.$toast('请求出错')
							});
							break;
						case 2:
							that.$axios('/api/train/sort2').then((res) => {
								// console.log(res.data)
								that.trainlist = res.data.tranlist
							}).catch((err) => {
								that.$toast('请求出错')
							});
							break;
						case 3:
							that.$axios('/api/train/sort3').then((res) => {
								// console.log(res.data)
								that.trainlist = res.data.tranlist
							}).catch((err) => {
								that.$toast('请求出错')
							});
							break;
						case 4:
							that.$axios('/api/train/sort4').then((res) => {
								// console.log(res.data)
								that.trainlist = res.data.tranlist
							}).catch((err) => {
								that.$toast('请求出错')
							});
							break;
						case 5:
							that.$axios('/api/train/sort5').then((res) => {
								// console.log(res.data)
								that.trainlist = res.data.tranlist
							}).catch((err) => {
								that.$toast('请求出错')
							});
							break;
						case 6:
							that.$axios('/api/train/sort6').then((res) => {
								// console.log(res.data)
								that.trainlist = res.data.tranlist
							}).catch((err) => {
								that.$toast('请求出错')
							});
							break;
					}
				}, 100)
			}


		},
		methods: {
			home() {
				this.$router.push('/train/sort')
			},
			train_detail(id) {
				this.$router.push('/train/traindetail/' + id)
			}

		},
		mounted: function() {


			// 请求我们的头部列表
			this.$axios({
				methods: 'post',
				url: '/api/train/listheader',
			}).then((res) => {
				// console.log(res.data)
				if (Object.keys(res.data) != 0) {
					this.shuju1 = true;
					this.trainimg = res.data.trainimg;
				} else {
					this.shuju1 = false
				}

			}).catch((err) => {

			})
			// 请求我们的下面列表
			this.$axios({
				methods: 'post',
				url: '/api/train/list',
			}).then((res) => {
				// console.log(res.data)
				if (Object.keys(res.data) != 0) {
					this.trainlist = res.data.trainlist
				} else {
					this.shuju = false
				}
			}).catch((err) => {
				this.$toast('请求出错')
			})
		}
	}
</script>

<style lang="less" scoped="scoped">
	
	.home_nav {
		box-shadow: 0px 0px 15px #f0f0f0;

		.home-left-nav {
			color: #000000;
			vertical-align: middle;
			font-size: 14px;

			&:before {
				vertical-align: -2px;
			}
		}

		.right_icon {
			color: #000;
			font-size: 18px;
		}
	}

	.icon-caidan {
		font-size: 28px;
		color: #323232;
	}

	.train_content {
		padding: 15px;
		box-sizing: border-box;

		.train_header {
			position: relative;
			margin-bottom: 20px;

			.train_img {
				img {
					width: 100%;
					position: relative;
					border-radius: 10px;
					box-shadow: 0px 5px 20px #ddd;
				}
			}

			.train_header_cont {
				position: absolute;
				bottom: 10px;
				padding-left: 20px;
				color: #fff;
				width: 90%;

				h4 {
					overflow: hidden;
				}

				p {
					font-size: 14px;
					line-height: 30px;
					font-weight: normal;

					.biao {
						background: #f1f1f1;
						border-radius: 5px;
						float: right;
						padding: 0px 8px;
						font-size: 12px;
						color: #323232;
						line-height: 26px;
					}
				}
			}
		}

		.train_cont_item {
			.train_item {
				height: 100px;
				padding: 20px 0px;
				border-bottom: 1px solid #f1f1f1;
				position: relative;

				.img_tu {
					img {
						width: 140px;
						height: 90px;
					}
				}

				.train_item_right {
					padding-left: 8px;

					h4 {
						overflow: hidden;
						text-overflow: ellipsis;
						white-space: nowrap;
						font-size: 15px;
					}

					p.time {
						font-weight: normal;
						line-height: 30px;
						font-size: 13px;
						color: #666;
					}

					p {
						span {
							background: #f1f1f1;
							border-radius: 5px;
							padding: 2px 8px;
							font-size: 12px;
							color: #323232;
							line-height: 26px;
							position: absolute;
							bottom: 30px;
						}
					}
				}
			}
		}
	}
</style>
