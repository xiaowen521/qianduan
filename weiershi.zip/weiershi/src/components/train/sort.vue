<template>
	<div class="sort">
		
		<div class="home_header">
			<van-nav-bar class='home_nav' title='培训' fixed  @click-right='back()'>
				
				<van-icon class='right_icon' name='cross' slot='right' ></van-icon>
			</van-nav-bar>
		</div>
		<div class="sort_item">
			<h4>请选择文章分类</h4>
			<div class="sort_flex">
				<van-button  :class="[sortnum==1 ? 'active' :'nomarl']" @click='sort(1)'>销售技能</van-button>
				<van-button  :class="[sortnum==2 ? 'active' :'nomarl']" @click='sort(2)'>技能成长</van-button>
				<van-button  :class="[sortnum==3 ? 'active' :'nomarl']"  @click='sort(3)'>运动课程</van-button>
				<van-button  :class="[sortnum==4 ? 'active' :'nomarl']"  @click='sort(4)'>局部减肥</van-button>
				<van-button  :class="[sortnum==5 ? 'active' :'nomarl']"  @click='sort(5)'>增肌食谱</van-button>
				<van-button  :class="[sortnum==6 ? 'active' :'nomarl']"  @click='sort(6)'>减肥食谱</van-button>
			</div>
			<van-button  size='large' :class="[sortnum==100 ? 'active' :'nomarl']"  @click='sort(100)'>全部文章</van-button>
		</div>
		
		
	</div>
</template>

<script>
	export default {
		name:'sort',
		// props:['activenum'],

		data(){
			return {
				content:'',
			}
		},
		computed:{
			// 计算属性 计算我们的sort值
			sortnum(){
				return this.$store.state.sort
			}
		},
		methods:{
			
			back(){
				this.$router.go(-1)
			},
			sort(value){
				this.$store.commit('changesort',value)
				// this.$emit('changesort')   //这个主要是在父子组件上面 体现的方法
				this.$router.push('/train')
			}
		},
		mounted:function(){
			console.log(this.$store.state.sort)
		}
	}
</script>

<style lang="less" scoped="scoped">
	.right_icon{
		font-size: 16px;
		color: #333;
	}
	.sort_item{
		padding: 15px;
		h4{
			padding: 15px 0px;
			font-size: 15px;
			color:#303034;
			line-height:22px;
		}
		.sort_flex{
			display: flex;
			flex: 1;
			justify-content: space-between;
			flex-wrap: wrap;
			.van-button{
				padding: 0 24px;
				margin-bottom: 15px;
				height: 38px;
				line-height: 38px;
			}
			
			
		}
		.active{
			background: #FEC949;
			color: #fff;
			border: 0px;
		}
		.nomarl{
			background: #f5f5f5;
			border: 0px;
		}
	}
	
	
</style>
