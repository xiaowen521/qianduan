<template>
	<div class="train_detail">
		<!-- <div class="bgcolor"></div> -->
		<!-- <div class="home_header">
			<van-nav-bar class='home_nav' title='培训' fixed  @click-right='home'>
				<van-icon class='right_icon' name='wap-home' slot='right' ></van-icon>
			</van-nav-bar>
		</div> -->
		<div class="detail_cont">
			<h2 class="news_title">{{content.title}}{{content.title}}</h2>
			<p class="detail_biao"><span class="detail_item_title">{{content.autor}}</span><span class="pull-right news_time">{{content.time}}</span></p>
			
			<p class="main_content">从 2015 年 4 月起，Ant Design 在蚂蚁金服中后台产品线迅速推广，对接多条业务线，覆盖系统 800 个以上。定位于中台业务的 Ant Design 兼顾专业和非专业的设计人员，具有学习成本低、上手速度快、实现效果好等特点，并且提供从界面设计到前端开发的全链路生态，可以大大提升设计和开发的效率。</p>
			<p class="main_content">{{content.cont}}{{content.cont}}</p>
			<p class="main_content">{{content.cont}}{{content.cont}}</p>
			<p class="main_content">{{content.cont}}{{content.cont}}</p>
			<p class="main_content">{{content.cont}}{{content.cont}}</p>
			<p class="main_content">{{content.cont}}{{content.cont}}</p>
		</div>
		
		<div class="news_detail_footer">
			<van-icon name='arrow-left' class='pull-left left-icon' @click='back()'>返回</van-icon>
			<van-icon name='eye-o'  class='pull-right right-icon'> <span>已看882088208820人</span></van-icon>
			
		</div>
		<div class="static_height"></div>
		<router-view></router-view>
	</div>
</template>

<script>
	export default {
		name:'traindetail',
		// props:['activenum'],

		data(){
			return {
				content:'',
				
			}
		},
		computed:{
			
		},
		methods:{
			home(){
				
			},
			back(){
				this.$router.go(-1)
			}
		},
		mounted:function(){
			console.log(this.$route.params.id)
			let id = this.$route.params.id
			this.$axios({
				url:'/api/train/list/detail',
				type:'get',
				params:{
					id:id
				}
			}).then((res)=>{
				console.log(res)
				this.content = res.data.traindetail
			}).catch((err)=>{
				console.log(res)
			})
		}
	}
</script>

<style lang="less" scoped="scoped">
	.train_detail{

		.detail_cont{
			padding: 15px;
			.detail_biao{
				padding: 14px 10px;
				text-indent: 0px;
			}
			.detail_item_title{
				padding: 5px 10px;
				background: #f5f5f5;
				border-radius:5px; 
				font-size: 12px;
			}
			.news_time{
				font-weight: normal;
				color: #898A92;
				font-size: 12px;
			}
			.main_content{
				padding-top: 10px;
				font-size: 16px;
				line-height: 29px;
			}
			.news_title{
				padding: 10px 0px;
				font-size: 24px;
			}
			h2{
				text-align: center;
			}
			p{
				text-align: justify;
				text-indent: 2em;
			}
		}
		.news_detail_footer{
			position: fixed;
			bottom: 0px;
			left: 0px;
			height: 50px;
			width: 100%;
			z-index: 100;
			line-height: 50px;
			background: #fff;
			padding: 0px 10px;
			box-sizing: border-box;
			border-top: 1px solid #efefef;
			box-shadow: 0px 0px 80px #ddd;
			.left-icon{
				line-height: 50px;
			}
			.right-icon{
				line-height: 50px;
				font-size: 22px;
				span{
					font-size: 14px;
					padding-left: 5px;
					vertical-align: 5px;
					line-height: 50px;
					// display: inline-block;
				}
			}
		}
	}
	
</style>
