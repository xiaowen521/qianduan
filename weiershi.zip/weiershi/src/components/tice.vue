<template>
	<div class="tice">
		<!-- 头部引用开始 -->
		<div class="home_header">
			<van-nav-bar class='home_nav' title='体侧详情' fixed @click-left='back()'  style="background: #ffa305;color: #fff;">
				<van-icon name='arrow-left' slot='left' class='home-left-nav'>返回</van-icon>
				<!-- <van-icon class='right_icon' name='wap-home' slot='right'></van-icon> -->
			</van-nav-bar>
		</div>
		<!-- <div class="bgcolor"></div> -->
		
		<!-- 头部引用结束 -->
		<div class="tice_header">
			<van-row>
				<van-col span='18'>
					<p class="fen">55</p>
					<p class="time">2018年11月11日 16：00</p>
				</van-col>
				<van-col span='6'>
					<p class="lishi_qian"><span class="lishi">历史趋势</span></p>
				</van-col>
			</van-row>
		</div>
		<div style="background: #F2F2F2;height: 20px;"></div>
		<!-- tab 切换 -->
		<div class="">
			<van-tabs v-model='activetab'>
				<van-tab title='综合'>
					<div class="tice_tabs">
						<div class="teacher_say">
							<h4>教练点评</h4>
							<p>一大堆加油的话一大堆加油的话一大堆加油的话一大堆加油的话一大堆加油的话一大堆加油的话一大堆加油的话</p>
						</div>
						
						<div class="tice_cont">
							<div class="tice_indicators">
								<h4 class="tice_title">体重<span class="result"> 正常</span></h4>
							</div>
							<div class="tice_process">
								<van-progress :percentage="progress_val" color='#8fd5fc'  class='tice_pro'></van-progress>
								<van-icon name='chart-trending-o' class='tice_icon' @click='chatshow'></van-icon>
							</div>
							<div class="progress_value"><h2>{{progress_val}}kg</h2></div>
						</div>
						
						<div class="tice_cont">
							<div class="tice_indicators">
								<h4 class="tice_title">去脂体重<span class="result"> 正常</span></h4>
							</div>
							<div class="tice_process">
								<van-progress :percentage="progress_val" color='#8fd5fc' class='tice_pro'></van-progress>
								<van-icon name='chart-trending-o' class='tice_icon'></van-icon>
							</div>
							<div class="progress_value"><h2>{{progress_val}}kg</h2></div>
						</div>
						
						<div class="tice_cont">
							<div class="tice_indicators">
								<h4 class="tice_title">肥胖度<span class="result"> 正常</span></h4>
							</div>
							<div class="tice_process">
								<van-progress :percentage="progress_val" color='#8fd5fc' class='tice_pro'></van-progress>
								<van-icon name='chart-trending-o' class='tice_icon'></van-icon>
							</div>
							<div class="progress_value"><h2>{{progress_val}}kg</h2></div>
						</div>
						
						<div class="tice_cont">
							<div class="tice_indicators">
								<h4 class="tice_title">BMI<span class="result"> 正常</span></h4>
							</div>
							<div class="tice_process">
								<van-progress :percentage="progress_val" color='#8fd5fc' class='tice_pro'></van-progress>
								<van-icon name='chart-trending-o' class='tice_icon'></van-icon>
							</div>
							<div class="progress_value"><h2>{{progress_val}}kg</h2></div>
						</div>
						
						<div class="tice_cont">
							<div class="tice_indicators">
								<h4 class="tice_title">BMR<span class="result"> 正常</span></h4>
							</div>
							<div class="tice_process">
								<van-progress :percentage="progress_val" color='#8fd5fc' class='tice_pro'></van-progress>
								<van-icon name='chart-trending-o' class='tice_icon'></van-icon>
							</div>
							<div class="progress_value"><h2>{{progress_val}}kg</h2></div>
						</div>
						
						<div class="tice_cont">
							<div class="tice_indicators">
								<h4 class="tice_title">体脂百分比<span class="result"> 正常</span></h4>
							</div>
							<div class="tice_process">
								<van-progress :percentage="progress_val" color='#8fd5fc' class='tice_pro'></van-progress>
								<van-icon name='chart-trending-o' class='tice_icon'></van-icon>
							</div>
							<div class="progress_value"><h2>{{progress_val}}kg</h2></div>
						</div>
						
					</div>
					
				</van-tab>
				<van-tab title='肌肉'></van-tab>
				<van-tab title='脂肪'></van-tab>
				<van-tab title='水分'></van-tab>
			</van-tabs>
		</div>
		<!-- 弹窗的 -->
		<van-popup v-model='showisok' position=''>
			<div class="chat_zhong">
				<ve-line :data="chartData" :settings="chartSettings"></ve-line>
			</div>
			
		</van-popup>
		
	</div>
</template>

<script>
	var data1= [
		{ '日期': '1/1', '访问用户': 393, },
		{ '日期': '1/2', '访问用户': 530,  },
		{ '日期': '1/3', '访问用户': 923,   },
		{ '日期': '1/4', '访问用户': 723,  },
		{ '日期': '1/5', '访问用户': 792, },
		{ '日期': '1/6', '访问用户': 593,  }
	]
	export default {
		name:'tice',
		data(){
			this.chartSettings = {
				stack: { '用户': ['访问用户', '下单用户'] },
				area: true
			  }
			return {
				tice:'',
				activetab:0,
				progress_val:50,
				showisok:false,
				chartData: {
				  columns: ['日期', '访问用户', ],
				  rows: data1
				}
			}
		},
		computed:{
			
		},
		methods:{
			back() {
				this.$router.go(-1)
			},
			chatshow(){
				this.showisok=true
			}
			
		},
		monuted(){
			
		}
	}
</script>

<style lang="less" scoped="scoped">
	.home_nav{
		box-shadow: none;
		// border-bottom: 1px solid salmon;
	}
	.tice_header{
		height: 150px;
		background: #ffa305;
		.fen{
			font-size: 40px;
			color: #fff;
			line-height: 80px;
			padding-left: 20px;
			margin-top: 20px;
		}
		.time{
			font-size: 12px;
			color: #fff;
			padding-left: 20px;
		}
		.lishi_qian{
			margin-top: 50px;text-align: right;padding-right: 20px;
			.lishi{
				color: #fff;
				background: #f29b28;
				padding: 5px;
				font-size: 13px;
			}
		}
	}
	
	.tice_tabs{
		padding: 15px;
		.teacher_say{
			background: #fff;
			padding: 15px;
			border-radius: 8px;
			box-shadow: 0px 0px 30px #ddd;
			p{
				line-height: 25px;
				font-size: 14px;
				color: #666;
				margin-top: 10px;
			}
		}
		.tice_cont{
			padding: 15px 0px;
			border-bottom: 1px solid #ddd;
			.tice_indicators{
				height: 25px;
				.result{
					float: right;
					background: #3edb9b;
					padding: 2px 8px;
					border-radius: 3px;
					color: #fff;
					font-size: 12px;
				}
			}
			.tice_process{
				.tice_pro{
					width: 85%;
					display: inline-block;
				}
				.tice_icon{
					text-align: center;
					font-size: 22px;
					margin-left: 15px;
				}
				
			}
			.progress_value{
				text-align: center;
				line-height: 30px;
			}
		}
	}
	
	.chat_zhong{
		width: 300px;
		max-width: 380px;
		min-width: 260px;
		padding: 10px;
		position: relative;
		margin: 0 auto;
	}
	
	
</style>
