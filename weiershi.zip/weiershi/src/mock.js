//引入mockjs
import Mock from 'mockjs'
//使用mockjs模拟数据
// 使用 Mock


// 登录的模板数据加载
Mock.mock('/api/login',{
	'username':'xiaoxiaowen',
	'password':'123123'
})
// 忘记密码的的找值
Mock.mock('/api/forget',{
	'token':'123456'
})
// 培训的两个接口
Mock.mock('/api/train/listheader',{
	'trainimg':{
		'img':Mock.Random.image('350x200'),
		'title':Mock.Random.csentence(),
		'time':Mock.Random.date('yyyy-MM-dd'),
		'biao|1':['销售技能','销售技巧']
	}
})
Mock.mock('/api/train/list',{
	'trainlist|5':[{
			'jiid|+1':1,
			'title':Mock.Random.csentence(),
			'time': Mock.Random.date('yyyy-MM-dd'),
			'jineng|1':['销售技能','销售技巧'],
			'img':Mock.Random.image('200x100'),
	}]	
})
// 培训详情的数据
Mock.mock(/\/api\/train\/list\/detail[\s\S]*?/,'get',function(req){
	console.log('req',req)
	console.log(req)
	return {
		'traindetail':{
			'title':Mock.Random.ctitle(),
			'time':Mock.Random.date('yyyy-MM-dd'),
			'autor':Mock.Random.cname(),
			'cont':Mock.Random.cparagraph()
		}
	}
	
})

// 培训的筛选问题开始
Mock.mock('/api/train/sort1',{
	'tranlist|5':[{
		'jiid|+1':1,
		'title':Mock.Random.csentence(),
		'time':Mock.Random.date('yyyy-MM-dd'),
		'jineng':'销售技能',
		'img':Mock.Random.image('200x100'),
	}]
})
Mock.mock('/api/train/sort2',{
	'tranlist|5':[{
		'jiid|+1':1,
		'title':Mock.Random.csentence(),
		'time':Mock.Random.date('yyyy-MM-dd'),
		'jineng':'技能成长',
		'img':Mock.Random.image('200x100'),
	}]
})
Mock.mock('/api/train/sort3',{
	'tranlist|5':[{
		'jiid|+1':1,
		'title':Mock.Random.csentence(),
		'time':Mock.Random.date('yyyy-MM-dd'),
		'jineng':'运动课程',
		'img':Mock.Random.image('200x100'),
	}]
})
Mock.mock('/api/train/sort4',{
	'tranlist|5':[{
		'jiid|+1':1,
		'title':Mock.Random.csentence(),
		'time':Mock.Random.date('yyyy-MM-dd'),
		'jineng':'局部减肥',
		'img':Mock.Random.image('200x100'),
	}]
})
Mock.mock('/api/train/sort5',{
	'tranlist|5':[{
		'jiid|+1':1,
		'title':Mock.Random.csentence(),
		'time':Mock.Random.date('yyyy-MM-dd'),
		'jineng':'增肌食谱',
		'img':Mock.Random.image('200x100'),
	}]
})
Mock.mock('/api/train/sort6',{
	'tranlist|5':[{
		'jiid|+1':1,
		'title':Mock.Random.csentence(),
		'time':Mock.Random.date('yyyy-MM-dd'),
		'jineng':'减肥食谱',
		'img':Mock.Random.image('200x100'),
	}]
})

// 我们首页的问题 加载当前时间的项目问题
Mock.mock('/api/home/times',{
	'timeitem|6':[{
		'id|+1':1,
		'time|1':['08:01','09:20'],
		'isok|1':[true,false],
		'title|1':Mock.Random.ctitle(),
		'lesson|1':['游泳课程','耐力课程',],
		'address|1':['拓基大厦A座','拓基大厦B座'],
		'dot|1':['日程','课程','联系'],
	}]
})
// 我们首页的问题 加载当前时间的项目问题
Mock.mock('/api/home/timess',{
	'timeitem|6':[{
		'id|+1':1,
		'time|1':['08:01','09:20'],
		'isok|1':[true,false],
		'title|1':Mock.Random.ctitle(),
		'lesson|1':['游泳课程','耐力课程',],
		'address|1':['拓基大厦A座','拓基大厦B座'],
		'dot|1':['日程','课程','联系'],
	}]
})

Mock.mock('/api/contact','post',function(options){
	
	// var options.body
	var data = JSON.parse(options.body) 
	console.log(data.contacts)
	if(data.contacts ==2){
		return '加油'
	}else{
		return true
	}
	
})

// 跟进管理的api接口
Mock.mock('/api/work/follow',{
	'follow|5':[{
		'id|+1':1,
		'photo':Mock.Random.image('50X50'),
		'name':Mock.Random.cname(),
		'fentime':Mock.Random.date('yyyy-MM-dd'),
		'overdue':Mock.Random.date('yyyy-MM-dd'),
		'nomal|1':['潜客','活跃'],
		'times':'四小时前',
	}]
})
Mock.mock('/api/work/follow1',{
	'follow|5':[{
		'photo':Mock.Random.image('50X50'),
		'name':Mock.Random.cname(),
		'lesson':Mock.Random.ctitle(),
		'lessonlong|1-10':1,
		'freelesson':Mock.Random.ctitle(),
		'nomal|1':['正式会员'],
	}]
})
Mock.mock('/api/work/follow2',{
	'follow|5':[{
		'photo':Mock.Random.image('50X50'),
		'name':Mock.Random.cname(),
		'lesson':Mock.Random.csentence(),
		'lessonlong|1-10':1,
		'overdue':Mock.Random.date('yyyy-MM-dd'),
		'nomal|1':['正式会员','非正式会员'],
	}]
})
Mock.mock('/api/work/follow3',{
	'follow|5':[{
		'photo':Mock.Random.image('50X50'),
		'name':Mock.Random.cname(),
		'lesson':Mock.Random.csentence(),
		'lessonlong|1-10':1,
		'overdue':Mock.Random.date('yyyy-MM-dd'),
		'nomal|1':['正式会员','非正式会员'],
		'times':'20天前',
		'nearlesson':Mock.Random.ctitle(),
	}]
})
// 
var data1 = Mock.mock({
		'follow|5':[{
				'photo':Mock.Random.image('50X50'),
				'name':Mock.Random.cname(),
				'lesson':Mock.Random.csentence(),
				'lessonlong|1-10':1,
				'overdue':Mock.Random.date('yyyy-MM-dd'),
				'nomal|1':['正式会员','非正式会员'],
				'times':'20天前',
				'nearlesson':Mock.Random.ctitle(),
			}],
		})

Mock.mock(/\/api\/work\/custom[\s\S]*?/,'get',function (option) {
	console.log(option)
	if(option){
		return Mock.mock({
		'follow|5':[{
				'id|+1':1,
				'photo':Mock.Random.image('50X50'),
				'name':Mock.Random.cname(),
				'lesson':Mock.Random.csentence(),
				'lessonlong|1-10':1,
				'overdue':Mock.Random.date('yyyy-MM-dd'),
				'nomal|1':['正式会员','非正式会员'],
				'times':'20天前',
				'nearlesson':Mock.Random.ctitle(),
			}],
		})
	}else{
		return false
	}
})


// 上传头像
Mock.mock('/api/uploader','post',function (option) {
	// console.log(option)
	let img = JSON.parse(option.body) 
	if(option){
		return img.value
	}else{
		return false
	}
})

Mock.mock(/\/api\/changephone/,'get',function (option) {
	console.log(option)
	if(option){
		return 123456
	}else{
		return false
	}
})


// 测试mock 是否加载  在浏览器上的控制台 查看
var data = Mock.mock({
    // 属性 list 的值是一个数组，其中含有 1 到 10 个元素
    'list|1-10': [{
        // 属性 id 是一个自增数，起始值为 1，每次增 1
        'id|+1': 1
    }]
})
// 输出结果
console.log(JSON.stringify(data, null, 4))