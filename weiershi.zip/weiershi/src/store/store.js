import Vue from 'vue'
import vuex from 'vuex'
Vue.use(vuex);


export default new vuex.Store({
   state:{
	   token:'',
	   sort:'2',
	   choose:[],
   },
   mutations:{
	   changetoken(state,value){
		   state.token = value
	   },
	   changesort(state,value){
	   		state.sort = value
	   },
	   changechoose(state,value1){
		   // console.log(value1)
	   		state.choose = value1
	   }
   }
   
})