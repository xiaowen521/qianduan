import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'

import Home from '@/components/Home'
// 注册登录
import Login from '@/components/login'
import Forget from '@/components/Forget'
// 培训
import Train from '@/components/train/Train'
import Traindetail from '@/components/train/traindetail'
// import Detail from '@/components/train/detail'
import sort from '@/components/train/sort'
import contact from '@/components/contact'
// 工作
import work from '@/components/Work'
// 工作  会籍
import follow from '@/components/works/follow'
import custom from '@/components/works/custom'
import choose from '@/components/works/choose'
import search from '@/components/works/search'
import addcustom from '@/components/works/addcustom'
import addcustom2 from '@/components/works/addcustom2'
import invitation from '@/components/works/invitation'
import addinvitation from '@/components/works/addinvitation'
import addinvitation2 from '@/components/works/addinvitation2'
import invitationdetail from '@/components/works/invitationdetail'
import customdetail from '@/components/works/customdetail'
import customsources from '@/components/works/customsources'
import sourceschoose from '@/components/works/sourceschoose'
// 工作 教练
import tcustom from '@/components/works/tcustom'
import tfollow from '@/components/works/tfollow'
import tchoose from '@/components/works/tchoose'
import tcustomdetail from '@/components/works/tcustomdetail'
import tsearch from '@/components/works/tsearch' 
import tyue from '@/components/works/tyue' 
import tcontact from '@/components/works/tcontact' 
import tentry from '@/components/works/tentry'
import tentry2 from '@/components/works/tentry2'
import tentry3 from '@/components/works/tentry3'

import tcustomsources from '@/components/works/tcustomsources'
import tsourceschoose from '@/components/works/tsourceschoose'
import tclass from '@/components/works/tclass'
import tyuedetail from '@/components/works/tyuedetail'
import tyuedetailteam from '@/components/works/tyuedetailteam'
// 快捷的几个页面
import customlist from '@/components/quick/add/customlist'
import addrecord from '@/components/quick/add/addrecord'
import customyue from '@/components/quick/yuyue/customyue'
import yuelesson from '@/components/quick/yuyue/yuelesson'
import customyao from '@/components/quick/yaoyue/customyao'
import addinvit from '@/components/quick/yaoyue/addinvit'

import customtice from '@/components/quick/tice/customtice'
import addschedule from '@/components/quick/schedule/addschedule'
import scheduledetail from '@/components/quick/schedule/scheduledetail'

// 工作 图表 
import personchart from '@/components/datachart/personchart'
import persondetail from '@/components/datachart/persondetail'


// 我的
import mine from '@/components/mines/mine'
import changephone from '@/components/mines/changephone'
import changephone2 from '@/components/mines/changephone2'
import changepsd from '@/components/mines/changepsd'
import about from '@/components/mines/about'
import advice from '@/components/mines/advice'
import tice from '@/components/tice'
import myaddress from '@/components/mines/myaddress'

Vue.use(Router)

export default new Router({
	mode:'history',
	routes: [
		{
		  path: '/',
		  name: 'home',
		  component: Home
		},
		// 登录
		{
		  path: '/login',
		  name: 'login',
		  component: Login
		},
		{
		  path: '/forget',
		  name: 'forget',
		  component: Forget
		},
		// 培训
		{
		  path: '/train',
		  name: 'train',
		  component: Train,
		},
		{
		  path : '/train/traindetail/:id',
		  name:'traindetail',
		  component:Traindetail,
		},
		
		{
		  path: '/train/sort',
		  name: 'sort',
		  component: sort
		},
		{
		  path: '/contact',
		  name: 'contact',
		  component: contact
		},
		//  工作 会籍
		{
			path:'/work',
			name:'work',
			component:work
		},
		{
			path:'/work/follow',
			name:'follow',
			component:follow
		},
		{
			path:'/work/custom',
			name:'custom',
			component:custom
		},
		{
			path:'/work/addcustom',
			name:'addcustom',
			component:addcustom
		},
		{
			path:'/work/addcustom2',
			name:'addcustom2',
			component:addcustom2
		},
		{
			path:'/work/invitation',
			name:'invitation',
			component:invitation
		},
		{
			path:'/work/addinvitation',
			name:'addinvitation',
			component:addinvitation
		},
		{
			path:'/work/addinvitation2/:id',
			name:'addinvitation2',
			component:addinvitation2
		},
		{
			path:'/work/invitationdetail/:id',
			name:'invitationdetail',
			component:invitationdetail
		},
		{
			path:'/work/customdetail/:id',
			name:'customdetail',
			component:customdetail
		},
		{
			path:'/work/customsources',
			name:'customsources',
			component:customsources
		},
		{
			path:'/work/sourceschoose',
			name:'sourceschoose',
			component:sourceschoose
		},
		{
			path:'/work/choose',
			name:'choose',
			component:choose
		},
		{
			path:'/work/search',
			name:'search',
			component:search
		},
		// 工作 教练
		{
			path:'/work/tcustom',
			name:'tcustom',
			component:tcustom
		},
		{
			path:'/work/tfollow',
			name:'tfollow',
			component:tfollow
		},
		{
			path:'/work/tchoose',
			name:'tchoose',
			component:tchoose
		},
		{
			path:'/work/tcustomdetail/:id',
			name:'tcustomdetail',
			component:tcustomdetail
		},
		{
			path:'/work/tsearch',
			name:'tsearch',
			component:tsearch
		},
		{
			path:'/work/tyue',
			name:'tyue',
			component:tyue
		},
		{
			path:'/work/tcontact',
			name:'tcontact',
			component:tcontact
		},
		{
			path:'/work/tentry',
			name:'tentry',
			component:tentry
		},
		{
			path:'/work/tentry2',
			name:'tentry2',
			component:tentry2
		},
		{
			path:'/work/tentry3',
			name:'tentry3',
			component:tentry3
		},
		
		{
			path:'/work/tcustomsources',
			name:'tcustomsources',
			component:tcustomsources
		},
		{
			path:'/work/tsourceschoose',
			name:'tsourceschoose',
			component:tsourceschoose
		},
		{
			path:'/work/tclass',
			name:'tclass',
			component:tclass
		},
		{
			path:'/work/tyuedetail/:id',
			name:'tyuedetail',
			component:tyuedetail
		},
		{
			path:'/work/tyuedetailteam/:id',
			name:'tyuedetailteam',
			component:tyuedetailteam
		},
		// 工作 我的数据报表
		
		{
			path:'/datachart/personchart',
			name:'personchart',
			component:personchart
		},
		{
			path:'/datachart/persondetail',
			name:'persondetail',
			component:persondetail
		},
		// 快捷添加的几个页面
		{
			path:'/quick/add/customlist',
			name:'customlist',
			component:customlist
		},
		{
			path:'/quick/add/addrecord/:id',
			name:'addrecord',
			component:addrecord
		},
		{
			path:'/quick/yuyue/customyue',
			name:'customyue',
			component:customyue
		},
		{
			path:'/quick/yuyue/yuelesson/:id',
			name:'yuelesson',
			component:yuelesson
		},
		{
			path:'/quick/yaoyue/customyao',
			name:'customyao',
			component:customyao
		},
		{
			path:'/quick/yaoyue/addinvit/:id',
			name:'addinvit',
			component:addinvit
		},
		{
			path:'/quick/tice/customtice',
			name:'customtice',
			component:customtice
		},
		{
			path:'/quick/schedule/addschedule',
			name:'addschedule',
			component:addschedule
		},
		{
			path:'/quick/schedule/scheduledetail',
			name:'scheduledetail',
			component:scheduledetail
		},
		// 我的
		{
			path:'/mine',
			name:'mine',
			component:mine
		},
		{
			path:'/mine/changephone',
			name:'changephone',
			component:changephone
		},
		{
			path:'/mine/changephone2',
			name:'changephone2',
			component:changephone2
		},
		{
			path:'/mine/changepsd',
			name:'changepsd',
			component:changepsd
		},
		{
			path:'/mine/about',
			name:'about',
			component:about
		},
		{
			path:'/mine/advice',
			name:'advice',
			component:advice
		},
		
		{
		  path: '/mine/myaddress',
		  name: 'myaddress',
		  component: myaddress
		},
		{
			path:'/tice',
			name:'tice',
			component:tice
		},
		{
		  path: '/hello',
		  name: 'HelloWorld',
		  component: HelloWorld
		},
		{
			path:'*',
			component:Home,
			redirect:'/'
		}
	]
})
